function [cost,optrunPre,optrunSuf] = OptRun(Aprod,S,gamma)
% S is initial state by default
% gamma=1;
% What are inputs and outputs? What forms are they and what do they mean?
% The inputs are product automaton, the initial state and gamma
% PBA's state: first number is region number, the second is the Buchi's
% state number
if cellfun('isempty',S)
    prompt1 = 'Input initial states in cell form, like {[a1,b1],...}';
    S=input(prompt1);
end
if cellfun('isempty',Aprod.F)
    prompt2 = 'Input accepting states in cell form, like {[a1,b1],...}';
    F=input(prompt2);
else
    F=Aprod.F;
end
% Calculate the number of states in NBA and regions in Tc system.
% To calculate the index of Q0 and F in Q of Aprod.
%length_Q=length(Aprod.Q);
length_Q0=length(S);
length_F=length(F);
Wp=sparse(Aprod.Wp);
%Qnew=[1:length_Q];

prefixCell=cell(length_Q0,length_F);
% Why it is length_Q0 here? 
suffixCell=cell(1,length_F);
costMat=zeros(length_Q0,length_F);
for j=1:length_F
    Fidx=(F{j}(1)-1)*Aprod.NoState+F{j}(2);%the index of F in Q.
    [sufcost,sufrun]=DijksCycle(Wp,Fidx);%return a zero matrix if no cycle exists.
    suffixCell{j}={sufcost,sufrun};    
    for i=1:length_Q0
        Q0idx=(S{i}(1)-1)*Aprod.NoState+S{i}(2);%the index of Q0 in Q.
        [precost,prerun,~] = graphshortestpath(Wp,Q0idx,Fidx);%return a zero matrix if no path found.
        prefixCell{i,j}={precost,prerun};
        costMat(i,j)=precost+gamma*sufcost;
    end
end
[cost,I]=min(costMat(:));
if cost>1e50
    error('No run can be found.');
else
    [I_row, I_col] = ind2sub(size(costMat),I);
    Pre=prefixCell{I_row,I_col}{2};
    Suf=suffixCell{1,I_col}{2};

    optrunPre=cell(1,length(Pre));
    optrunSuf=cell(1,length(Suf));
    for ipre=1:length(Pre)
        optrunPre{ipre}=Aprod.Q{1,Pre(ipre)};
    end
    for isuf=1:length(Suf)
        optrunSuf{isuf}=Aprod.Q{1,Suf(isuf)};
    end
end

end