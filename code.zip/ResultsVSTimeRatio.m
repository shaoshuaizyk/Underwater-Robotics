%Cost VS Time_ratio
close all;
clear;
clc;
Map = [-5,-5,5,5,-5;-5,5,5,-5,-5];%Clockwise by default
ObstacleMap=[];
time_ratio=linspace(0,1,11);%[0.01,0.05,0.1,1,10];
N=4000;%[500,1000,1500,2000];
% time_mode='Constant';
% time_mode='Variable';
m=cell(1,length(time_ratio));
start_time=0;
x_init=[4;-4;1];
x_goal=[-4;4;1];
total_cost =zeros(1,length(time_ratio));
energy_cost=zeros(1,length(time_ratio));
travel_time=zeros(1,length(time_ratio));
repeat_num=3;
for i=1:length(time_ratio)
    obj=RRTstar_time_v3(Map,ObstacleMap,time_ratio(i),'MeanderingJet','Variable',start_time);
    obj.x_init=x_init;
    obj.x_goal=x_goal;
    tc=zeros(1,length(repeat_num));
    ec=zeros(1,length(repeat_num));
    tt=zeros(1,length(repeat_num));
    for j=1:repeat_num
        G=obj.ConstructTree(x_init,N);
        [tc(j),ec(j),tt(j),~,~]=obj.findpath(G,x_init,x_goal);
    end
    total_cost(i)=sum(tc)/length(tc);
    energy_cost(i)=sum(ec)/length(ec);
    travel_time(i)=sum(tt)/length(tt);
    disp(i)
end
figure()
subplot(311)
plot(time_ratio,total_cost)
ylabel('Total Cost')
subplot(312)
plot(time_ratio,energy_cost)
ylabel('Energy Cost')
subplot(313)
plot(time_ratio,travel_time)
ylabel('Travel Time')
suptitle('Results VS Time Ratio')