classdef RRTstar
    properties
%         Map = [-50,-50,50,50,-50;-50,50,50,-50,-50];%for circle current
%         Map=[0,0,100,100,0;0,100,100,0,0];% Default clockwise
        Map = [-5,-5,5,5,-5;-5,5,5,-5,-5];%current model
%         ObstacleMap=[20,20,40,40,60,60,20;20,60,60,40,40,20,20];
        ObstacleMap=[];
        %If the obstacle areas are separated, use NAN to separate.
        Map_free;
%         Map_current=[];
        x_init;%=[4;-4];
        x_goal;%=[-4;4]; x_goal can be an area that satisfies some properties
    end
    properties
        eta=1; %Range for steer and near function
        N; %Iteration times
        robot_mode_ratio; %1 for top speed, 0 for variant speed
%         robot_mode='constant_speed';
%         robot_mode='variant_speed';
%         current_mode='Circle';
        current_mode;%='MeanderingJet';
%         current_mode='current_map';
%         current_mode='None';
        vel_mode = 'Constant';
%         vel_mode = 'VariableWithEqualTimeStep';
%         vel_mode = 'VariableWithUnequalTimeStep';
        large_num;
        % For transforming coordinates into index, make code work faster
        cd = 0.1; % vehicle drag coefficient
        v_current=2;%current velocity for circle currents
%         v_vehicle=2;%vehicle velocity
        v_abs=2;    %absolute velocity for quick robots
        v_max=1.5;    %top speed of robots
        gammaRRTstar;
        % should greater than 4^dim*(vol(Map_free)/vol(unitball))
%         rewire_time;
    end
    
    methods
        function obj=RRTstar(Map,ObstacleMap,robot_mode_ratio,current_mode,vel_mode)%,x_init,x_goal)
            if nargin~=0
                obj.Map=Map;
                obj.ObstacleMap=ObstacleMap;
    % %             obj.N=N;
                obj.robot_mode_ratio=robot_mode_ratio;
                obj.current_mode=current_mode;
                obj.vel_mode=vel_mode;
            end
% %             obj.x_init=x_init;
% %             obj.x_goal=x_goal;
% %             The input can be:
% %             RRTstar()
% %             RRTstar(N)
% %             RRTstar(N,eta)
% %             RRTstar(N,eta,x_init,x_goal)
% %             RRTstar(N,eta,Map,ObstacleMap,x_init,x_goal)
%             switch nargin
%                 case 0
%                     %Do nothing
%                 case 1
%                     obj.N=N;
%                 case 2
%                     obj.N=N;
%                     obj.eta=eta;
%                 case 4
%                     obj.N=N;
%                     obj.eta=eta;
%                     obj.x_init=x_init;
%                     obj.x_goal=x_goal;                    
%                 case 6
%                     obj.N=N;
%                     obj.eta=eta;
%                     obj.x_init=x_init;
%                     obj.x_goal=x_goal;
%                     obj.Map=Map;
%                     obj.ObstacleMap=ObstacleMap;
%                 otherwise
%                     error('Error input');
%             end
            if isempty(obj.ObstacleMap) %No obstacle
                free_x = obj.Map(1,:);
                free_y = obj.Map(2,:);
            else %There are obstacles, so the outer boundary should be
                %counter-clockwise
                if all(ispolycw(obj.Map(1,:),obj.Map(2,:)))% No hole
                    [map1,map2]=poly2ccw(obj.Map(1,:),obj.Map(2,:));
                    free_x = [map1,NaN,obj.ObstacleMap(1,:)];
                    free_y = [map2,NaN,obj.ObstacleMap(2,:)];
                else
                    %With holes, the outer and inner boundaries are in opposite directions
                    [obmap1,obmap2]=poly2ccw(obj.ObstacleMap(1,:),obj.ObstacleMap(2,:));
                    free_x = [obj.Map(1,:),NaN,obmap1];
                    free_y = [obj.Map(2,:),NaN,obmap2];
                end
            end
            obj.Map_free=[free_x;free_y];
            obj.large_num = (max(max(obj.Map)) - min(min(obj.Map)));
            volumn_Map = (max(obj.Map(1,:)) - min(obj.Map(1,:)))*...
                (max(obj.Map(2,:)) - min(obj.Map(2,:)));
            obj.gammaRRTstar = 4^2*volumn_Map;
        end %set object
        
        function [path,graph]=main(obj,N,x_init,x_goal,robot_mode_ratio,current_mode)
            %Graph might be used
            tic;
            obj.N=N;
            obj.x_init=x_init;
            obj.x_goal=x_goal;
            obj.robot_mode_ratio=robot_mode_ratio;
            obj.current_mode=current_mode;
            G=obj.ConstructTree(x_init,N);
            [goalcost,travel_time,path,Ggoal]=obj.findpath(G,x_init,x_goal);
            fprintf('Finding path costs %fs\n',toc);
            tic;
            figure();
            hold on
            obj.PlotMap();
            obj.PlotCurrent();
            obj.PlotGraph(Ggoal);
            obj.PlotPath(path);
            hold off
            fprintf('Plotting costs %fs\n',toc);
            graph=Ggoal{2};
            fprintf('The cost of the path is %f\n',goalcost);
            fprintf('The travel time is %f\n',travel_time);
            fprintf('\n');
        end %Main Function Ends
        
        function G=ConstructTree(obj,x_init,N)
%             % Construct trees in the whole map or in the submap
%             if nargin==3
%                 obj.Map=subMap;
%                 if isempty(obj.ObstacleMap) %No obstacle
%                     free_x = obj.Map(1,:);
%                     free_y = obj.Map(2,:);
%                 else %There is obstacle, so the outer boundary should be
%                     %counter-clockwise
%                     if ispolycw(obj.Map(1,:),obj.Map(2,:))
%                         [map1,map2]=poly2ccw(obj.Map(1,:),obj.Map(2,:));
%                         free_x = [map1,NaN,obj.ObstacleMap(1,:)];
%                         free_y = [map2,NaN,obj.ObstacleMap(2,:)];
%                     end
%                 end
%                 
%             end
            obj.N=N;
            obj.x_init=x_init;
            V=x_init;
            E=[];
            i=0;
%             obj.rewire_time=0;
            x_min=min(obj.Map(1,:));
            x_max=max(obj.Map(1,:));
            y_min=min(obj.Map(2,:));
            y_max=max(obj.Map(2,:));
            while i < obj.N
                G={V,E};
%                 rng('shuffle');
                rand_x = x_min+rand()*(x_max-x_min);
                rand_y = y_min+rand()*(y_max-y_min);
                x_rand = [rand_x;rand_y];
                in = inpolygon(rand_x,rand_y,...
                    obj.Map_free(1,:),obj.Map_free(2,:));
                if in
                    i = i + 1;
                    [V,E]=obj.RRTstar_extend(G,x_rand);
                    if mod(length(V),4000)==0
                        disp(length(V));
                    end
                end
            end
        end %ConstructTree ends
        
        function [goalcost,travel_time,path,G]=findpath(obj,G,x_init,x_goal,r,sloc)
%             Then find a path to goal
%             The goal can be an area
%             sloc is the location of the acoustic sender,
%             r is the radius of the communication range
%             findpath(obj,G,x_init,x_goal)
%                 x_init is a point, x_goal can be an area or a point;
%                 If x_goal is a point add it into the tree
%                 If x_goal is an area and has no hole inside, extend a point inside to the tree
%             findpath(obj,G,x_init,x_goal,r)
%                 x_goal should be a point, r is the range
%                 Add x_goal into the tree
%             findpath(obj,G,x_init,x_goal,r,sloc)
%                 x_goal should be an area, r is the communication range, sloc is the sender loction
%                 Add a point inside x_goal and sloc into the tree
            obj.x_init=x_init;
            V=G{1};
            E=G{2};
            if size(x_goal,2)==1 % If the goal is a point, add this point to the tree
                obj.x_goal=x_goal;
            elseif size(x_goal,2)>1 && isempty(find(isnan(x_goal(1,:)), 1))
                % No hole area. If there are holes inside, do not choose a inner
                % point to extend
                centroid=sum(x_goal,2)/size(x_goal,2);
                obj.x_goal=centroid;
            end
            if nargin==6 % Add sender into the graph
                [V,E]=obj.RRTstar_extend(G,sloc);
                G={V,E};
            end
            if ~isempty(obj.x_goal)
                [V,E]=obj.RRTstar_extend(G,obj.x_goal);
                G={V,E};%Add a point in the goal area into the graph
            end
            if nargin==4 && size(x_goal,2)==1
                % A point as a goal
                current_x = x_goal;
            else
                if nargin==5% && size(x_goal,2)==1
                    % a sender location and a range
                    goal_node_idx=obj.Dis(x_goal,V)<=r;
                    % All nodes are less or equal to r away from the sender
                elseif nargin==4 && size(x_goal,2)>1
                    goal_node_idx=inpolygon(V(1,:),V(2,:),x_goal(1,:),x_goal(2,:));
                    % All nodes are in(not on) the goal region
                elseif nargin==6
                    % An area and a sender location and a range
                    goal1_idx=inpolygon(V(1,:),V(2,:),x_goal(1,:),x_goal(2,:));
                    goal2_idx=obj.Dis(sloc,V)<=r;
                    goal_node_idx=goal1_idx & goal2_idx;
                    if isempty(find(goal_node_idx,1))
                        error('Increase sample numbers');
                    end
                end
                goal_node=V(:,goal_node_idx);
                goal_cost=zeros(1,size(goal_node,2));
                for i_goal=1:size(goal_node,2)
                    goal_cost(i_goal)=obj.Cost(goal_node(:,i_goal),E);
                end
                [~,current_x_idx]=min(goal_cost);
                current_x=goal_node(:,current_x_idx);
            end
            obj.x_goal=current_x;
            E_no = size(E,2);
            path = zeros(2,E_no+1);
            
            flag = 0;
            for k = linspace(E_no+1,1,E_no+1)
                path(:,k) = current_x;
                if isequal(current_x,obj.x_init)
                    flag = 1;
                    break;
                else
                    current_x = obj.RRTparent(current_x, E);
                end
            end
            if flag == 0
                error('Cannot find a path');
            end
            path = path(:,k:end);
            [goalcost,travel_time] = obj.Cost(obj.x_goal,E);
%             fprintf('The cost of the path is %f\n',goalcost);
%             fprintf('The travel time is %f\n',travel_time);
        end %FindPath ends
        
        function PlotMap(obj)
            plot(obj.Map_free(1,:),obj.Map_free(2,:),'b-','LineWidth',2);
            axis equal
            xlim([min(obj.Map(1,:)),max(obj.Map(1,:))]);
            ylim([min(obj.Map(2,:)),max(obj.Map(2,:))]);
        end %PlotMap ends
        
        function PlotCurrent(obj)
            X=linspace(min(obj.Map(1,:)), max(obj.Map(1,:)), obj.large_num);
            Y=linspace(min(obj.Map(2,:)), max(obj.Map(2,:)), obj.large_num);
            [x,y]=meshgrid(X,Y);
            [ux,uy]=obj.current_velocity(x,y);
%             figure();
%             hold on
            quiver(X,Y,ux,uy);
%             hold off
%             switch obj.current_mode
%                 case 'None'
%                     %Do nothing
%                 case 'Circle'
%                     ux = -obj.v_current*y./sqrt(x.^2+y.^2+eps);
%                     uy =  obj.v_current*x./sqrt(x.^2+y.^2+eps);
%                     quiver(X,Y,ux,uy);
%                 case 'MeaderingJet'
%                     t=0;
% 
%                     %m=zeros(length(t)); %when use movie(m), m must not be set in advance
%                     A=1.2;          %average meander width
%                     c=0.12;         %phase speed with which they they shift downstream
%                     k=2*pi/7.5;     %number of meanders in the unit length
%                     w=0.4;          %frequency of the modulation
%                     epsilon=0.3;    %amplitude of the modulation
% 
%                     for i=1:length(t)
%                         B=A+epsilon*cos(w*t(i));
%                         num=y-B*sin(k*(x-c*t(i)));
%                         den=sqrt(1+k^2*B^2*cos(k*(x-c*t(i))).^2);
%                         fra=num./den;
% %                         phi=-tanh(fra);
%                         ux = sech(fra).^2./den;
%                         uy = ((B^2*k^3*sin(k*(x-c*t(i))).*cos(k*(x-c*t(i))).*num)...
%                             ./ (den.^3) - (y - num)./den).*(-sech(fra).^2);
% %                         contour(X,Y,phi)
% %                         hold on
%                         quiver(X,Y,ux,uy)
%                     end
%                 otherwise
%                     %Do nothing
%             end
        end %current_plot ends

        function PlotPath(obj,path)
                plot(path(1,:),path(2,:),'r-',...
                'LineWidth',2,...
                'Marker','o',...
                'MarkerSize',2,...
                'MarkerFacecolor','r',...
                'MarkerEdgeColor','r');
            text(path(1,1),path(2,1),'Start','color','black','FontSize',14);
            text(path(1,end),path(2,end),'End','color','black','FontSize',14);
        end %PlotPaht ends
            
        function PlotGraph(obj,G)
            E=G{2};
            graph = E;
            for i = 1:size(graph,2)
                x = [graph(1,i),graph(3,i)];
                y = [graph(2,i),graph(4,i)];
                plot(x,y,'g-');
                hold on
            end
        end %PlotGraph ends
                
    end %Open methods ends
        
    methods(Access = private)
        
        function [V, E] = RRTstar_extend(obj,G,x)
            V_new = G{1};
            E_new = G{2};
            x_nearest = obj.Nearest(G,x);
            x_new = obj.Steer(x_nearest,x);
            if obj.passable(x_nearest, x_new)%, obj.Map_free)
                V_new = obj.RRTaddNode(V_new,x_new);
                x_min = x_nearest;
                X_near = obj.Near(G,x_new,size(G{1},2));
                min_cost=obj.Cost(x_min, E_new)+obj.costP2P(x_min,x_new);
        %         if ~isempty(X_near)
                    for i = 1 : size(X_near,2)
                        if obj.passable(X_near(:,i),x_new)%, obj.Map_free)
                            new_cost = obj.Cost(X_near(:,i), E_new) +...
                                obj.costP2P(X_near(:,i),x_new);
                            if  new_cost <  min_cost
                                x_min = X_near(:,i);
                                min_cost=new_cost;
                            end
                        end
                    end
        %         end
                E_new = obj.RRTaddEdge(E_new,[x_min; x_new]);    
                X_near = obj.RRTremoveNode(X_near,x_min);
                for j = 1 : size(X_near,2)  %Rewire the graph
                    cost_rewire = min_cost +...
                        obj.costP2P(x_new,X_near(:,j));
                    if obj.passable(x_new,X_near(:,j))...,obj.Map_free)...
                            && (obj.Cost(X_near(:,j), E_new) > cost_rewire)
                        x_parent = obj.RRTparent(X_near(:,j), E_new);
                        E_new = obj.RRTremoveEdge(E_new,[x_parent; X_near(:,j)]);
                        E_new = obj.RRTaddEdge(E_new, [x_new; X_near(:,j)]);
%                         obj.rewire_time=obj.rewire_time+1;
                    end
                end
            end
            V = V_new;
            E = E_new;
        end %RRTstar_extend ends
        
        function T_or_F = passable(obj, p1, p2)%, Map_free)
        % The path between two points is passable, including obstacle free
        % and current being unable to stop the robot
%             line_x = [p1(1,:),p2(1,:)];
%             line_y = [p1(2,:),p2(2,:)];
            line_x = linspace(p1(1,:), p2(1,:),obj.large_num);
            line_y = linspace(p1(2,:), p2(2,:),obj.large_num);
%             [xin,yin]=inpolygon(line_x,line_y,Map_free(1,:),Map_free(2,:));
            [in,on]=inpolygon(line_x,line_y,obj.Map_free(1,:),obj.Map_free(2,:));
%             cost=obj.costP2P(p1,p2); % Just regard the cost as inf, so we
%             can set up an edge and then rewire it.
            if all(in + on)% && cost<1e10
                T_or_F = true;
            else
                T_or_F = false;
            end
        end %isObstacleFree ends
        
        function [cost,time]=costP2P(obj,p1,p2)
        %x and y are coordinates
        %x and y can be vectors
        %What if p1 = p2
            line_x = linspace(p1(1,:), p2(1,:),obj.large_num*10);
            line_y = linspace(p1(2,:), p2(2,:),obj.large_num*10);
            [v_cx,v_cy]=obj.current_velocity(line_x,line_y);
            x_direction=line_x(2:end)-line_x(1:end-1);
            y_direction=line_y(2:end)-line_y(1:end-1);
            direction_unit=[x_direction;y_direction]./(sqrt(x_direction.^2+y_direction.^2)+eps);
            v_c=[v_cx(1:end-1);v_cy(1:end-1)];
            speedc_along_direction=diag(v_c'*direction_unit)';
            vc_along_direction=direction_unit.*speedc_along_direction;
            vc_verticle=v_c-vc_along_direction;
            vr_verticle=-vc_verticle;
            constant_speed=ones(1,length(vc_along_direction));
            variant_speed=speedc_along_direction<=0;%Need to be fixed
            clip=obj.robot_mode_ratio*constant_speed+...
                (1-obj.robot_mode_ratio)*variant_speed;
%             switch obj.robot_mode
%                 case 'constant_speed' %keep top speed
%                     clip=ones(1,length(vc_along_direction));
%                 case 'variant_speed' %save energy when go with flow
%                     clip=speedc_along_direction<=0;
%             end
            speedr_verticle=sqrt(vr_verticle(1,:).^2+vr_verticle(2,:).^2);
            speedr_along_direction=sqrt(obj.v_max^2-speedr_verticle.^2).*clip;
            vr_along_direction=speedr_along_direction.*direction_unit;
            vr_abs=vr_along_direction+vc_along_direction;
            speed_abs_along_direction=sqrt(vr_abs(1,:).^2+vr_abs(2,:).^2);
            if all(~direction_unit) %when p1 = p2
                cost=0;
                time=0;
            elseif all(sqrt(vc_verticle(1,:).^2+vc_verticle(2,:).^2)<=obj.v_max) && all(diag(vr_abs'*direction_unit)>0)
                travel_time=sqrt(x_direction.^2+y_direction.^2)./(speed_abs_along_direction);
                % the travel time of intervals
                speedr=sqrt(speedr_along_direction.^2+speedr_verticle.^2);
                cost=obj.cd*sum(travel_time.*speedr.^3);
                time=sum(travel_time);
            else
                cost=inf;
                time=inf;
            end
        end % cost_P2P ends %cross_current ends

        function [ux,uy]=current_velocity(obj,x,y)
            switch obj.vel_mode
                case 'Constant'
                    switch obj.current_mode
                        case 'Circle'
                            ux = -obj.v_current*y./sqrt(x.^2+y.^2+eps);
                            uy =  obj.v_current*x./sqrt(x.^2+y.^2+eps);
                        case 'MeanderingJet'
                            A=1.2;          %average meander width
                            c=0.12;         %phase speed with which they they shift downstream
                            k=2*pi/7.5;     %number of meanders in the unit length
                            w=0.4;          %frequency of the modulation
                            epsilon=0.3;    %amplitude of the modulation
                            t=0; %Time invariant
                            for i=1:length(t)
                                B=A+epsilon*cos(w*t(i));
                                num=y-B*sin(k*(x-c*t(i)));
                                den=sqrt(1+k^2*B^2*cos(k*(x-c*t(i))).^2);
                                fra=num./den;
                            %   phi=-tanh(fra);
                                ux = sech(fra).^2./den;
                                uy = ((B^2*k^3*sin(k*(x-c*t(i)))...
                                    .*cos(k*(x-c*t(i))).*num) ./ (den.^3) ...
                                    - (y - num)./den).*(-sech(fra).^2);
                            end
                        case 'current_map'
                            ;
                        case 'None'
                            ux=zeros(1,length(x));
                            uy=zeros(1,length(y));
                    end
                case 'VariableWithEqualTimeStep'
                    ;
                case 'VariableWithUnequalTimeStep'
                    ;
            end
        end %current_velocity ends
        
        function V_new = RRTaddNode(obj,V,x)
            V_new = [V,x];
        end %RRTaddNode ends
        
        function V_new = RRTremoveNode(obj,V,x)
            if isempty(V)
                V_new = V;
            else
                V_idx = V(2,:)*obj.large_num + V(1,:);
                x_idx = x(2,:)*obj.large_num + x(1,:);
                [judge,idx]=ismember(x_idx,V_idx);
                if judge
                    V(:,idx)=[];
                    V_new = V;
                else
                    error('Cannot remove the node, because the node does not belong to the graph');
    %                 V_new = V;
                end
            end
        end %RRTremoveNode ends
        
        function E_new = RRTaddEdge(obj,E,e)
            if isequal(e(1:2),e(3:4))
            % check if the new edge contains the same node
                E_new = E;
            else
                E_new = [E,e];
            end
        end
        
        function E_new = RRTremoveEdge(obj,E,e)
            E_idx = E(4,:)*obj.large_num^3 + E(3,:)*obj.large_num^2 +...
                E(2,:)*obj.large_num + E(1,:);
            e_idx = e(4,:)*obj.large_num^3 + e(3,:)*obj.large_num^2 +...
                e(2,:)*obj.large_num + e(1,:);
            [judge, idx] = ismember(e_idx, E_idx);
            if judge
                E(:,idx)=[];
                E_new = E;
            else
                error('Cannot remove the edge, because the edge does not in the graph');
            end
        end %RRTremoveEdge ends
        
        function x_nearest = Nearest(obj,G,x)
            V = G{1};
            c = obj.Dis(V,x);
            [~,idx]=min(c);
            x_nearest=V(:,idx);
        end %Nearest ends
        
        function v = Near(obj,G,x,n)
            V = G{1};
            if n == 1
                rn = obj.eta;
            else
                rn = min(sqrt(obj.gammaRRTstar*log(n)/(pi*n)),obj.eta);
%                 rn = max(sqrt(obj.gammaRRTstar*log(n)/(pi*n)),obj.eta);
            end
            v = V(:,logical(obj.Dis(V,x)<=rn));
        end % Near ends
        
        function z = Steer(obj,x,y)
            if isequal(obj.x_goal,y) || obj.Dis(x,y) <= obj.eta
                z = y;
            else
                theta = linspace(0,2*pi,100);
                %Form a circle with r=eta first
                z1 = obj.eta * cos(theta);
                z2 = obj.eta * sin(theta);
                z = [z1;z2];
                z=x-z;
                %The circle center is at x
                D = obj.Dis(z,y);
                [~,idx]=min(D);
                z=z(:,idx);
            end
        end %Steer ends
        
        function x_p = RRTparent(obj, x, E)
            dim = 2;
            parentNode = E(1:dim,:);
            childNode = E(dim+1:end,:);
            childNode_idx = childNode(2,:)*obj.large_num + childNode(1,:);
            x_idx = x(2,:)*obj.large_num + x(1,:);
            [judge, idx] = ismember(x_idx,childNode_idx);
            if judge
                x_p = parentNode(:,idx);
            else
                error('cannnot find a parent node');
            end
        end %RRTparent ends
        
        function [cost,reachtime] = Cost(obj, x, E)
            % The cost from initial point to current point
            % The difference between time-variant and time-invariant here
            % is that the time-variant P2Pcost needs initial time, so it
            % should be find the path first and then calculate the cost and
            % travel time
            cost = 0;
            reachtime=0;
            flag = 0;
            if isempty(E)
                return
            end
            for i = 1 : size(E,2)+1
                if isequal(x,obj.x_init)
                    flag = 1;
                    break;
                else
                    x_parent = obj.RRTparent(x,E);
                    [c,t] = obj.costP2P(x_parent,x);
                    cost = cost + c;
                    reachtime = reachtime +t;
                    x = x_parent;
                end
            end
            if flag == 0
                error('cannot find a path');
            end
        end %Cost ends
        
        function c = Dis(obj,p1,p2)
        % generate a array consists of all distances from x1 to x2, the length of c
        % is equal to length of x1 or x2, which is longer.
            c = sqrt((p1(1,:) - p2(1,:)).^2+(p1(2,:) - p2(2,:)).^2);
        end
        
%         function cost = costP2P(obj,p1,p2)
%         % Actually it's the cost directly from point x1 to x2, if current
%         % is counted into consideration, the result is different from
%         % general distance definition.
%             switch obj.current_mode
%                 case 'None'
%                     cost = obj.Dis(p1,p2);
%                 case 'Circle'
%                     % Counter-clockwise circle current with center at(50,50)
%                     if obj.vel_mode == 'Constant'
%                         cost = obj.Circle_current(p1,p2);
% %                     elseif obj.vel_mode == 'VariableWithEqualTimeStep'
% %                         c = pass;
% %                     elseif obj.vel_mode == 'VariableWithUnequalTimeStep'
% %                         c = pass;
%                     end
%                 case 'MeaderingJet'
%                       if obj.vel_mode == 'Constant'
%                         cost = obj.MeaderingJet_current(p1,p2);
% %                     elseif obj.vel_mode == 'VariableWithEqualTimeStep'
% %                         c = pass;
% %                     elseif obj.vel_mode == 'VariableWithUnequalTimeStep'
% %                         c = pass;
%                       end
%                 otherwise
%                     cost = obj.Dis(p1,p2);
%             end
%         end %costP2P ends
%         
%         function cost = Circle_current(obj,p1,p2)
%             interval = obj.large_num*10;
%             Disx=p2(1)-p1(1);
%             Disy=p2(2)-p1(2);
%             Dis_s=sqrt(Disx^2+Disy^2);
%             ds=Dis_s/interval;
%             x=linspace(p1(1),p2(1),interval+1);
%             y=linspace(p1(2),p2(2),interval+1);
%             ux = -obj.v_current*y./sqrt(x.^2+y.^2+eps);
%             uy =  obj.v_current*x./sqrt(x.^2+y.^2+eps);
%             fV = (obj.v_abs*Disx/Dis_s-ux).^2+(obj.v_abs*Disy/Dis_s-uy).^2;
%             cost = obj.cd*(sum(fV)-(fV(1)+fV(end))/2)*ds;
%             % Trapezoidal Rule
%         end % Circle_current ends 
%         
%         function cost = MeaderingJet_current(obj,p1,p2)
%             A=1.2;          %average meander width
%             c=0.12;         %phase speed with which they they shift downstream
%             k=2*pi/7.5;     %number of meanders in the unit length
%             w=0.4;          %frequency of the modulation
%             epsilon=0.3;    %amplitude of the modulation
% %             obj.cd = 0.1;       %dragging coefficient
%             interval = obj.large_num*10;
%             Disx=p2(1)-p1(1);
%             Disy=p2(2)-p1(2);
%             Dis_s=sqrt(Disx^2+Disy^2);
%             ds=Dis_s/interval;
%             x=linspace(p1(1),p2(1),interval+1);
%             y=linspace(p1(2),p2(2),interval+1);
%             t=0; %Time invariant
%             for i=1:length(t)
%                 B=A+epsilon*cos(w*t(i));
%                 num=y-B*sin(k*(x-c*t(i)));
%                 den=sqrt(1+k^2*B^2*cos(k*(x-c*t(i))).^2);
%                 fra=num./den;
% %                 phi=-tanh(fra);
%                 ux = sech(fra).^2./den;
%                 uy = ((B^2*k^3*sin(k*(x-c*t(i))).*cos(k*(x-c*t(i))).*num) ./ (den.^3) - (y - num)./den).*(-sech(fra).^2);
%                 fV = (obj.v_abs*Disx/Dis_s-ux).^2+(obj.v_abs*Disy/Dis_s-uy).^2;
%                 cost = obj.cd*(sum(fV)-(fV(1)+fV(end))/2)*ds;
%                 % Trapezoidal Rule
%             end
%         end % MeaderingJet_current ends


    end %Private methods end
    
end