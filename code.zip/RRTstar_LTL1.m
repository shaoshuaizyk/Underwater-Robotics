%RRT* & LTL for static environments
% close all;
% clear;
% clc;
function RRTstar_LTL1(N,robot_mode_ratio)
tic;
%% Input maps and obstacles
Map = [-5,-5,5,5,-5;-5,5,5,-5,-5];%Clockwise by default
ObstacleMap=[];
%If the obstacle areas are separated, use NAN to separate.
current_mode='MeanderingJet';
vel_mode='Constant';
obj=RRTstar(Map,ObstacleMap,robot_mode_ratio,current_mode,vel_mode);
% obj.v_max, obj.cd will be used in heuristic cost
% heuristic cost is the energy cost for straight paths in highest speed
% without currents
%% Construct the weighted transition system(WTS)
%         Region One
%         +-------+-------+-------+
%         |  r4 b | r5 rb |   r6  |
%         +-------+-------+-------+
%         |   c1  |   c2  |   c3  |
%         +-------+-------+-------+
%         |   r1  |  r2 b | r3 gb |
%         +-------+-------+-------+
%                     456
%                     789
%                     123
% p1=r1; p2=r2; p3=r3; p4=r4; p5=r5; p6=r6;
% p7=c1; p8=c2; p9=c3; p10=b; p11=rb;p12=gb
region_num=9;
Tc.region=1:region_num;
Tc.region0=1;
Tc.trans={'s','','','','','','s','','';
          '','s','','','','','','s','';
          '','','s','','','','','','s';
          '','','','s','','','s','','';
          '','','','','s','','','s','';
          '','','','','','s','','','s';
          's','','','s','','','s','s','';
          '','s','','','s','','s','s','s';
          '','','s','','','s','','s','s'};% Show the transitions

Tc.Lc={'p01','p02p10','p03p12','p04p10','p05p11','p06','p07','p08','p09'}; 
%When the number is more than 10, the number must have leading zeros
%The connection between the system and NBA. Each column represents a
%region, the contents are Labels.
% Region_trans=~cellfun('isempty',Tc.trans);
% Tc.Wc=double(Region_trans); 
Tc.Wc=zeros(region_num);%Initialize to be computed
Tc.T=zeros(region_num);
% Tc.Path=cell(region_num);

%% Establish LTL formula and Buchi automaton
% Problem 1
N_p=12;%number of atomic propositions that appear in the LTL formula
phi='F(p11 & F(p10)) & FG(p01)' ; %LTL formula
% phi='(GF(p03) & GF(p04) & GF(p06))';
alphabet=alphabet_set(obtainAlphabet(N_p));% alphabet, it is the powerset 2^{AP}, where AP is the set of atomic propositions
B1=create_buchi(phi,alphabet);%GF (p1 & F (p2 & F (p3 & F p4)) & G(!p5))
%%%% Negation "!" and Until "U" do not work correctly in create_buchi.m .

%% Discretize the maps and find center point of all sub-areas
%  Construct the sub-areas
x_min=min(Map(1,:));
x_max=max(Map(1,:));
y_min=min(Map(2,:));
y_max=max(Map(2,:));
vertex_x=linspace(x_min,x_max,4);
vertex_y=linspace(y_min,y_max,4);
[vertices_X,vertices_Y]=meshgrid(vertex_x,vertex_y);
vertices_X=reshape(vertices_X',1,[]);
vertices_Y=reshape(vertices_Y',1,[]);
vertices=[vertices_X;vertices_Y];
state=cell(1,region_num);
state{1}=[vertices(:,1),vertices(:,5),vertices(:,6),vertices(:,2)];
state{2}=[vertices(:,2),vertices(:,6),vertices(:,7),vertices(:,3)];
state{3}=[vertices(:,3),vertices(:,7),vertices(:,8),vertices(:,4)];
state{4}=[vertices(:,9),vertices(:,13),vertices(:,14),vertices(:,10)];
state{5}=[vertices(:,10),vertices(:,14),vertices(:,15),vertices(:,11)];
state{6}=[vertices(:,11),vertices(:,15),vertices(:,16),vertices(:,12)];
state{7}=[vertices(:,5),vertices(:,9),vertices(:,10),vertices(:,6)];
state{8}=[vertices(:,6),vertices(:,10),vertices(:,11),vertices(:,7)];
state{9}=[vertices(:,7),vertices(:,11),vertices(:,12),vertices(:,8)];
centroids=zeros(2,region_num);
for ii=1:region_num
    centroids(:,ii)=sum(state{ii},2)/size(state{ii},2);
end
%% Compute the communication range for large SNR
k_spreading_factor=1.5; % practical spreading
%k=2 for spherical spreading
%k=1 for cylindrical spreading
f=85;% acoustic frequency
N1=50; % Parameter in noise
eta_noise=18; % Parameter in noise
SNR_bar=10; % SNR threshold
P=1e9; % Acoustic power
delta_f=30; % receiver noise bandwidth
if f<1000
    a_f=(0.11*f^2/(1+f^2)+44*f^2/(4100+f)+2.75*1e-4*f^2+0.003);
elseif f>=1000
    a_f=(0.002+0.11*f^2/(1+f^2)+0.011*f^2);
end
syms range_l
eqn= 10*log10(P/delta_f)-k_spreading_factor*10*log10(range_l)-range_l*a_f-N1+eta_noise*log10(f)==10*log10(SNR_bar);
solv=solve(eqn,range_l);
l=vpa(solv);
%l is the range that satisfies the SNR requirement

%% Compute the heuristic weight function
% % % obj=RRTstar(N,robot_mode_ratio,current_mode,vel_mode,x_init,x_goal);
Region_trans=~cellfun('isempty',Tc.trans);
% % N=1000;
% % robot_mode_ratio=0.5;
% current_mode='MeanderingJet';
% vel_mode='Constant';
for i=1:size(Region_trans,1)
%     x_init=centroids(:,i); 
%     %Need to sample from initial points in the connected regions first,
%     %then define the goal points and find the paths
    for j=1:size(Region_trans,2)
        if i==j
            subcost=1e-5;
            subtime=0;
%             subpath=x_init;
        elseif Region_trans(i,j)==0
            subcost=0;
            subtime=0;
%             subpath=[];
        else
%             [subMap_x,subMap_y]=polybool('union',state{i}(1,:),state{i}(2,:),state{j}(1,:),state{j}(2,:));
%             % Merge two connected regions
%             subMap=[subMap_x;subMap_y];
%             subObstacleMap=ObstacleMap;
%             obj=RRTstar(subMap,subObstacleMap,robot_mode_ratio,current_mode,vel_mode);
%             %Should I change obstacle Map accordingly? Regard it as no
%             %obstacle so far
%             G_init=obj.ConstructTree(x_init,N);
%             x_goal=centroids(:,j);
%             [subcost,subtime,subpath,~]=obj.findpath(G_init,x_init,x_goal);...l);
            subtime=sqrt((centroids(1,i)-centroids(1,j))^2+(centroids(2,i)-centroids(2,j))^2)/obj.v_max;
            subcost=obj.cd*obj.v_max^3*subtime;
        end
        Tc.Wc(i,j)=subcost;
        Tc.T(i,j)=subtime;
%         Tc.Path{i,j}=subpath;
    end
end

%% Compute the optimal run
Aprod=FullProd(Tc,B1);
gamma=1;
[hcost,optrunPre,optrunSuf] = OptRun(Aprod,Aprod.Q0,gamma);
% Heuristic cost is the energy cost for straight paths in highest speed
% without currents

%% Calculate the real costs and path, plot the whole map
x_init=centroids(:,optrunPre{1}(1));
PrePath=x_init;
precost=0;
pretime=0;
for k=1:length(optrunPre)-1
    prestate=optrunPre{k}(1);
    sufstate=optrunPre{k+1}(1);
    [subMap_x,subMap_y]=polybool('union',state{prestate}(1,:),state{prestate}(2,:),...
        state{sufstate}(1,:),state{sufstate}(2,:));
    % Merge two connected regions
    subMap=[subMap_x;subMap_y];
    subObstacleMap=ObstacleMap;
    obj=RRTstar(subMap,subObstacleMap,robot_mode_ratio,current_mode,vel_mode);
    %Should I change obstacle Map accordingly? Regard it as no
    %obstacle so far
    G_init=obj.ConstructTree(x_init,N);
    x_goal=state{sufstate};
    if ismember(sufstate,[2,3,4,5]) % state with receivers
        sloc=[centroids(1,sufstate)+1;centroids(2,sufstate)-1];
        [subcost,subtime,subpath,~]=obj.findpath(G_init,x_init,x_goal,l,sloc);
    else
        [subcost,subtime,subpath,~]=obj.findpath(G_init,x_init,x_goal);
    end
    precost=subcost+precost;
    pretime=subtime+pretime;
    x_init=subpath(:,end);
    PrePath=[PrePath,subpath(:,2:end)];
end
sufcost=0;
suftime=0;
SufPath=[];
x_init=PrePath(:,end);
if length(optrunSuf)<=1
    SufPath=PrePath(:,end);
else
    for k=1:length(optrunSuf)-1
        prestate=optrunPre{k}(1);
        sufstate=optrunPre{k+1}(1);
        [subMap_x,subMap_y]=polybool('union',state{prestate}(1,:),state{prestate}(2,:),...
        state{sufstate}(1,:),state{sufstate}(2,:));
        % Merge two connected regions
        subMap=[subMap_x;subMap_y];
        subObstacleMap=ObstacleMap;
        obj=RRTstar(subMap,subObstacleMap,robot_mode_ratio,current_mode,vel_mode);
        %Should I change obstacle Map accordingly? Regard it as no
        %obstacle so far
        G_init=obj.ConstructTree(x_init,N);
        x_goal=state{sufstate};
        if ismember(sufstate,[2,3,4,5]) % state with receivers
            sloc=[centroids(1,sufstate)+1;centroids(2,sufstate)-1];
            [subcost,subtime,subpath,~]=obj.findpath(G_init,x_init,x_goal,l,sloc);
        else
            [subcost,subtime,subpath,~]=obj.findpath(G_init,x_init,x_goal);
        end
        sufcost=subcost+sufcost;
        suftime=subtime+suftime;
        x_init=subpath(:,end);
        SufPath=[SufPath,subpath(:,2:end)];
    end
end
cost=precost+gamma*sufcost;
time=pretime+gamma*sufcost;
obj=RRTstar(Map,ObstacleMap,robot_mode_ratio,current_mode,vel_mode);
figure();
hold on
obj.PlotMap();
% Plot Map
plot([vertices(1,5),vertices(1,8)],[vertices(2,5),vertices(2,8)],'k--')
plot([vertices(1,9),vertices(1,12)],[vertices(2,9),vertices(2,12)],'k--')
plot([vertices(1,2),vertices(1,14)],[vertices(2,2),vertices(2,14)],'k--')
plot([vertices(1,3),vertices(1,15)],[vertices(2,3),vertices(2,15)],'k--')
% Plot partition lines
cr = linspace(0,2*pi);
plot(centroids(1,2)+1+l*cos(cr),centroids(2,2)-1+l*sin(cr),'k');
plot(centroids(1,3)+1+l*cos(cr),centroids(2,3)-1+l*sin(cr),'k');
plot(centroids(1,4)+1+l*cos(cr),centroids(2,4)-1+l*sin(cr),'k');
plot(centroids(1,5)+1+l*cos(cr),centroids(2,5)-1+l*sin(cr),'k');
% Plot communication range
obj.PlotCurrent();
% Plot currents
plot(PrePath(1,:),PrePath(2,:),'r-',...
    'LineWidth',2,...
    'Marker','o',...
    'MarkerSize',2,...
    'MarkerFacecolor','r',...
    'MarkerEdgeColor','r');
plot(SufPath(1,:),SufPath(2,:),'b-');
% Plot paths
hold off;
fprintf('Running time is %fs\n',toc);
fprintf('Heuristic cost is %f\n',hcost);
fprintf('Total cost is %f\n',cost);
fprintf('Traveling time is %f\n',time);
fprintf('\n');
end