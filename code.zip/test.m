close all;
clc;
clear;

% dy = @(t,y) [y(2);y(1) + 1];
% options=odeset('events',@p2pEvent);
% [t,y] = ode45(dy,[0 12],[0 1],options);
p1=[3;-3];
p2=[-3;3];
time=0;
[totalcost,energycost,endtime]=costP2P(p1,p2,time);

function [position,isterminal,direction] = p2pEvent(t,y)
position = y(1); % The value that we want to be zero
isterminal = 1;  % Halt integration 
direction = 0;   % The zero can be approached from either direction
end

function [totalcost,energycost,endtime]=costP2P(p1,p2,start_time)
x_direction=p2(1)-p1(1);
y_direction=p2(2)-p1(2);
direction_unit=[x_direction;y_direction]/sqrt(x_direction^2+y_direction^2);
tr=0.01;
v_max=1.5;
rsr=0.5;
cd=0.1;
init_position=p2;
tspan=[start_time,1e50];
y0=[-sqrt(x_direction^2+y_direction^2),0];
options=odeset('events',@p2pEvent);
[~,~,te,ye,~] = ode45(@(t,y) odefcn(t,y,v_max,direction_unit,rsr,cd,init_position),tspan,y0,options);
endtime=te;
energycost=ye(2);
totalcost=energycost+tr*(endtime-start_time);
end %cross_current ends

function dydt=odefcn(t,y,v_max,direction_unit,rsr,cd,init_position)
% y(1) is displacement along the edge, y(2)y(3) is the current_x, current_y
% on the edge, y(4) is the energy
dydt=zeros(2,1);
xx=init_position(1)+y(1)*direction_unit(1);
yy=init_position(2)+y(1)*direction_unit(2);
[uc_x,uc_y]=current_velocity(xx,yy,t);
vc=[uc_x;uc_y];
speedc_along=vc'*direction_unit;
variant=speedc_along<0;
vc_verticle=vc-speedc_along*direction_unit;
speedc_verticle=norm(vc_verticle);
clip=rsr+(1-rsr)*variant;
dydt(1)=(sqrt(v_max^2-speedc_verticle^2)*clip+vc'*direction_unit);
dydt(2)=cd*(norm(-dydt(1)*direction_unit-vc))^3;
end

function [ux,uy]=current_velocity(x,y,time)
A=1.2;          %average meander width
c=0.12;         %phase speed with which they they shift downstream
k=2*pi/7.5;     %number of meanders in the unit length
w=0.4;          %frequency of the modulation
epsilon=0.3;    %amplitude of the modulation
B=A+epsilon*cos(w*time);
num=y-B*sin(k*(x-c*time));
den=sqrt(1+k^2*B^2*cos(k*(x-c*time)).^2);
fra=num./den;
%   phi=-tanh(fra);
ux = sech(fra).^2./den;
uy = ((B^2*k^3*sin(k*(x-c*time))...
    .*cos(k*(x-c*time)).*num) ./ (den.^3) ...
    - (y - num)./den).*(-sech(fra).^2);
end %current_velocity ends

% time=0;
% X=linspace(-5,5, 10);
% Y=linspace(-5,5, 10);
% [x,y]=meshgrid(X,Y);
% t=mod(time,4);
% if t>=0 && t<2
%     ratio=1-t;
% elseif t>=2 && t<4
%     ratio=-3+t;
% end
% dd=sqrt(x.^2+y.^2+eps);
% ux = -2*ratio*y./dd;
% uy =  2*ratio*x./dd;
% quiver(X,Y,ux,uy);
% k=10000;
% tic;
% for i=1:k
%     for j=1:length(k)
%         b=k(j);
%     end
% end
% disp(toc);
% clear;
% k=10000;
% tic;
% for i=1:k
%     b=k;
% end
% disp(toc);
% if aa(0,3)==0 && aa(3,2)>0
%     k=0;
% else
%     k=1;
% end
% disp(k)
% function [t,c]=aa(a,b)
% % if nargout == 1
% %     c=4;
% %     t=NaN;
% % else
%     t=a;
%     c=b;
% % end
% end
% tic
% for i=1:100
%     diag(ones(1000,2)*ones(2,1000));
% end
% disp(toc)
% global large_num cd robot_mode v_max v_current vel_mode current_mode
% large_num=10;
% cd=0.1;
% % robot_mode='constant_speed'; 
% robot_mode='variant_speed';
% v_max=2;
% v_current=1.5;
% vel_mode='Constant';    %VariableWithEqualTimeStep
% current_mode='Circle';
% % current_mode='MeanderingJet';
% % current_mode='None';
% disp(costP2P([-4;0],[4;0]))
% disp(costP2P([-4;0],[0;-4])+costP2P([0;-4],[4;0]))
%         function cost=costP2P(p1,p2)
%         global large_num cd robot_mode v_max %v_current vel_mode current_mode
%         %x and y are coordinates
%         %x and y can be vectors
%         %What if p1 = p2
%             line_x = linspace(p1(1,:), p2(1,:),large_num);
%             line_y = linspace(p1(2,:), p2(2,:),large_num);
%             [v_cx,v_cy]=current_velocity(line_x,line_y);
%             x_direction=line_x(2:end)-line_x(1:end-1);
%             y_direction=line_y(2:end)-line_y(1:end-1);
%             direction_unit=[x_direction;y_direction]./(sqrt(x_direction.^2+y_direction.^2)+eps);
%             v_c=[v_cx(1:end-1);v_cy(1:end-1)];
%             speedc_along_direction=diag(v_c'*direction_unit)';
%             vc_along_direction=direction_unit.*speedc_along_direction;
%             vc_verticle=v_c-vc_along_direction;
%             vr_verticle=-vc_verticle;
%             switch robot_mode
%                 case 'constant_speed' %keep top speed
%                     clip=ones(1,length(vc_along_direction));
%                 case 'variant_speed' %save energy when go with flow
%                     clip=speedc_along_direction<=0;
%             end
%             speedr_verticle=sqrt(vr_verticle(1,:).^2+vr_verticle(2,:).^2);
%             speedr_along_direction=sqrt(v_max^2-speedr_verticle.^2).*clip;
%             vr_along_direction=speedr_along_direction.*direction_unit;
%             vr_abs=vr_along_direction+vc_along_direction;
%             speed_abs_along_direction=sqrt(vr_abs(1,:).^2+vr_abs(2,:).^2);
%             if all(~direction_unit) %when p1 = p2
%                 cost=0;
%             elseif all(sqrt(vc_verticle(1,:).^2+vc_verticle(2,:).^2)<=v_max) && all(diag(vr_abs'*direction_unit)>0)
%                 travel_time=sqrt(x_direction.^2+y_direction.^2)./(speed_abs_along_direction);
%                 cost=cd*sum(travel_time.*speedr_verticle.^3+travel_time.*speedr_along_direction.^3);
%             else
%                 cost=inf;
%             end
%         end %cross_current ends
%         
%         function [ux,uy]=current_velocity(x,y)
%         global v_current vel_mode current_mode
%             switch vel_mode
%                 case 'Constant'
%                     switch current_mode
%                         case 'Circle'
%                             ux = -v_current*y./sqrt(x.^2+y.^2+eps);
%                             uy =  v_current*x./sqrt(x.^2+y.^2+eps);
%                         case 'MeanderingJet'
%                             A=1.2;          %average meander width
%                             c=0.12;         %phase speed with which they they shift downstream
%                             k=2*pi/7.5;     %number of meanders in the unit length
%                             w=0.4;          %frequency of the modulation
%                             epsilon=0.3;    %amplitude of the modulation
%                             t=0; %Time invariant
%                             for i=1:length(t)
%                                 B=A+epsilon*cos(w*t(i));
%                                 num=y-B*sin(k*(x-c*t(i)));
%                                 den=sqrt(1+k^2*B^2*cos(k*(x-c*t(i))).^2);
%                                 fra=num./den;
%                             %   phi=-tanh(fra);
%                                 ux = sech(fra).^2./den;
%                                 uy = ((B^2*k^3*sin(k*(x-c*t(i)))...
%                                     .*cos(k*(x-c*t(i))).*num) ./ (den.^3) ...
%                                     - (y - num)./den).*(-sech(fra).^2);
%                             end
%                         case 'current_map'
%                             ;
%                         case 'None'
%                             ux=zeros(1,length(x));
%                             uy=zeros(1,length(y));
%                     end
%                 case 'VariableWithEqualTimeStep'
%                     ;
%                 case 'VariableWithUnequalTimeStep'
%                     ;
%             end
%         end %current_velocity ends
% 
% A=1.2;          %average meander width
% c=0.12;         %phase speed with which they they shift downstream
% k=2*pi/7.5;     %number of meanders in the unit length
% w=0.4;          %frequency of the modulation
% epsilon=0.3;    %amplitude of the modulation
% cd = 0.1;       %dragging coefficient
% Vabs=2;
% p1=[-3;2];
% p2=[3;8];
% interval = 100;
% Disx=p2(1)-p1(1);
% Disy=p2(2)-p1(2);
% Dis_s=sqrt(Disx^2+Disy^2);
% ds=Dis_s/interval;
% x=linspace(p1(1),p2(1),interval+1);
% y=linspace(p1(2),p2(2),interval+1);
% t=0;
% for i=1:length(t)
%     B=A+epsilon*cos(w*t(i));
%     num=y-B*sin(k*(x-c*t(i)));
%     den=sqrt(1+k^2*B^2*cos(k*(x-c*t(i))).^2);
%     fra=num./den;
%     phi=-tanh(fra);
%     ux = sech(fra).^2./den;
%     uy = ((B^2*k^3*sin(k*(x-c*t(i))).*cos(k*(x-c*t(i))).*num) ./ (den.^3) - (y - num)./den).*(-sech(fra).^2);
%     fV = (Vabs*Disx/Dis_s-ux).^2+(Vabs*Disy/Dis_s-uy).^2;
%     cost = cd*(sum(fV)-(fV(1)+fV(end))/2)*ds;
%     % Trapezoidal Rule
% end



    % 
% k=

% function c = MeaderingJet_current(p1,p2)
% 
% 
% end

% syms x
% tic;
% for i = 1:1000
%     int(x,0,1);
% end
% disp(toc)
% string='a';
% 
% if string=='a'
%     disp(2);
% end
% tic;
% n = size(graph,2);
% for i = 1:n
%     x = [graph(1,i),graph(3,i)];
%     y = [graph(2,i),graph(4,i)];
%     plot(x,y,'b-');
%     hold on
% end
% disp(toc)


% eta=3;
% round = zeros(2,(eta*2+1)^2);
% for i = 1:eta
%     right = linspace(-i,i-1,2*i);
%     left  = linspace(i,-i+1,2*i);
%     round(1,(2*i-1)^2+1:(2*i-1)^2+2*i)=right;
%     round(2,(2*i-1)^2+1:(2*i-1)^2+2*i)=-i;
%     round(1,(2*i-1)^2+2*i+1:(2*i-1)^2+4*i)=i;
%     round(2,(2*i-1)^2+2*i+1:(2*i-1)^2+4*i)=right;
%     round(1,(2*i-1)^2+4*i+1:(2*i-1)^2+6*i)=left;
%     round(2,(2*i-1)^2+4*i+1:(2*i-1)^2+6*i)=i;
%     round(1,(2*i-1)^2+6*i+1:(2*i-1)^2+8*i)=-i;
%     round(2,(2*i-1)^2+6*i+1:(2*i-1)^2+8*i)=left;
% end


% Map=[0,0,100,100,0;0,100,100,0,0];% Default clockwise
% ObstacleMap=[20,20,40,40,60,60,20;20,60,60,40,40,20,20];
% % x_init=[10;10];
% % x_goal=[25;26];
% free_x = [Map(1,:),NaN,ObstacleMap(1,:)];
% free_y = [Map(2,:),NaN,ObstacleMap(2,:)];
% % line_x = linspace(x_init(1,:), x_goal(1,:),50);
% % line_y = linspace(x_init(2,:), x_goal(2,:),50);
% % [in,on]=inpolygon(line_x,line_y,ObstacleMap(1,:),ObstacleMap(2,:));
% figure(1);
% plot(free_x,free_y);
% axis equal
% hold on
% % plot(line_x(in),line_y(in),'r+');
% % plot(line_x(~in),line_y(~in),'bo');

% n=10000;
% a=[];
% b=zeros(3,n);
% x=[1;1;1];
% tic;
% for i=1:n
%     a=[a,x];
% end
% disp(toc)
% 
% tic;
% for i=1:n
%     b(:,i)=x;
% end
% disp(toc)


% large=10000;
% for l = 1 : 10000
%     a = ones(2,l);
%     b = [1;2];
%     a_idx=a(2,:)*large+a(1,:);
%     b_idx=b(2,:)*large+b(1,:);
%     [judge,idx]=ismember(b_idx,a_idx);
%     if judge
%         d = a(:,idx);
%     end
% end
% disp(toc);
% 
% clear;
% tic;
% large=10000;
% for l = 1 : 10000
%     a = ones(2,l);
%     a(:,3)=[2;2];
%     b = [1;1];
%     a_idx=a(2,:)*large+a(1,:);
%     b_idx=b(2,:)*large+b(1,:);
%     c=a_idx-b;
% end
% disp(toc);
% s=20000;
% A=1:s;
% B=1:s;
% X=zeros(s);
% [m,n]=size(X);
% 
% tic;
% C1=[sub2ind([m,n],A,B),sub2ind([m,n],A,B)];
% [x1,y1]=ind2sub([m,n],C1);
% disp(toc);
% 
% tic;
% C2=[(B-1)*m+A,(B-1)*m+A];
% x2=mod(C2,m);
% y2=ceil(C2/m);
% disp(toc);
% % % 
% % tic;
% % x=[3;3];
% % y=[6;6];
% % z = Steer(x,y);
% % disp(z);
% % disp(toc);
% % function z = Steer(x,y)
% %     eta = 2;
% %     z = zeros(2,(eta*2-1)^2);
% %     for i = -eta:eta
% %         for j = -eta:eta
% %             z(1:2,2*eta^2+(2*j+2)*eta+i+j+1)=[i,j];
% %         end
% %     end
% %     z=x-z;
% %     z=z(1:2,logical(dis(z,x)<=eta));
% %     [~,idx]=min(dis(z,y));
% %     z=z(1:2,idx);
% % end
% % 
% % function c = dis(x1,x2)
% %     c = sqrt((x1(1,:)-x2(1,:)).^2+(x1(2,:)-x2(2,:)).^2);
% % end
% % global x y
% % x=4;
% % y=2;
% % testglobal;
% % function testglobal
% % global x y
% % disp([x,y])
% % end
% clear;
% A = zeros(2,10000000);
% A(99999)=1;
% A(100000)=1;
% B = 1;
% tic;
% [judge,idx]=ismember(B,A);
% disp(toc)
% 
% 
% A = zeros(2,10000000);
% A(99999)=1;
% A(100000)=1;
% B = 1;
% tic;
% [i,j]=find(A==B);
% disp(toc)
% 
% p1=[1;1;1]; % map point subscripts begin from 1
% p2=[2;3;4];
% X=ones(4,4,4);
% X(1,1,2)=0;
% check = isObstacleFree2(p1,p2,X)
% function T_or_F = isObstacleFree2(p1,p2,X) 
% % Check obstacle in 2D or 3D maps,p is dim-by-1 vector
%     relative_pos = abs(p2 - p1);
%     [max_dis, dim_idx] = max(relative_pos);
%     sample_point = zeros(length(p1),max_dis+1);
%     for i = 1:length(p1)
%         sample_point(i,:) = linspace(p1(i),p2(i),max_dis+1); %dim-by-n matrix
%     end
%     check_point=[floor(sample_point),ceil(sample_point)];
%     num_ckpt = size(check_point,2);
%     check_point_idx = zeros(1,num_ckpt);
%     if length(p1)==2
%         for j = 1:num_ckpt
%             check_point_idx(j) = sub2ind(size(X),check_point(1,j),check_point(2,j));
%         end
%     elseif length(p1)==3
%         for j = 1:num_ckpt
%             check_point_idx(j) = sub2ind(size(X),check_point(1,j),check_point(2,j),check_point(3,j));
%         end
%     end
%     T_or_F = isempty(find(~X(check_point_idx),1));
% end

