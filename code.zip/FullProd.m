function Aprod=FullProd(Tc,B1)
NoRegion=length(Tc.region);
NoState=length(B1.S);
Aprod.Q0={};
% What does it look like?
% The first number is region number, the second one is the Buchi state number
Aprod.F={};
Aprod.NoRegion=NoRegion;
Aprod.NoState=NoState;
Aprod.trans=cell(NoRegion*NoState,NoRegion*NoState);
Aprod.Wp=zeros(NoRegion*NoState,NoRegion*NoState);
alpha=1;
for i=1:NoRegion
    for m=1:NoState
        pii=Tc.region(i);
        qm=B1.S(m);
        qs=[pii,qm];
        Aprod.Q{(i-1)*NoState+m}=qs;
        if ismember(qm,B1.S0) && ismember(pii,Tc.region0)
            Aprod.Q0{end+1}=qs;
        end
        if ismember(qm,B1.F)
            Aprod.F{end+1}=qs;
        end

        for j=postIdx(pii,Tc.trans)
            for n=postIdx(qm,B1.trans)
                %pij=Tc.region(j);
                qn=B1.S(n);
                %qg = [pij,qn];
                %idx = findpair(qg,Aprod.Q); %return the index of post(qs),i.e., qg, in Aprod.Q
                d = CheckTranB(qm,Tc.Lc{pii},qn,B1);
                if d >= 0
                    preidx=(i-1)*NoState+m;%The index for Aprod.trans and .Wp can be computed by i,j,m,n
                    proidx=(j-1)*NoState+n;
                    Aprod.trans{preidx,proidx}={Tc.trans{i,j},B1.trans{m,n}};
                    Aprod.alphabet=B1.alphabet;
                    Aprod.Wp(preidx,proidx)=Tc.Wc(i,j)+alpha*d;
                end
            end
        end
    end
end

end
