%RRT* & LTL for static environments
% close all;
% clear;
% clc;
function m=RRTstar_LTL2(N,time_ratio)
tic;
%% Input maps and obstacles
Map = [-5,-5,5,5,-5;-5,5,5,-5,-5];%Clockwise by default
ObstacleMap=[-3,-2.5,-2,-2.5,-3;-2.5,-2,-2.5,-3,-2.5];
%If the obstacle areas are separated, use NAN to separate.
current_mode='MeanderingJet';
% time_mode='Constant';
time_mode='Variable';
start_time=0;
obj=RRTstar_time_v3(Map,ObstacleMap,time_ratio,current_mode,time_mode,start_time);
% obj.v_max, obj.cd will be used in heuristic cost
% heuristic cost is the energy cost for straight paths in highest speed
% without currents
%% Construct the weighted transition system(WTS)
%         Region One
%         +-----------------------+
%         |                 s1    |
%         |     r3                |
%         |           r2          |
%         |       o1       r1     |
%         |   I1                  |
%         +-----------------------+
%
% p1=BG; p2=r1; p3=r2; p4=r3; p5=s1; p6=I1;

region_num=6;
Tc.region=1:region_num;
Tc.region0=6;
Tc.trans={'s','s','s','s','s','s';
          's','s','','','','';
          's','','s','','','';
          's','','','s','','';
          's','','','','s','';
          's','','','','','s';};% Show the transitions

Tc.Lc={'p1','p2','p3','p4','p5','p6'}; 
%When the number is more than 10, the number must have leading zeros
%The connection between the system and NBA. Each column represents a
%region, the contents are Labels.
% Region_trans=~cellfun('isempty',Tc.trans);
% Tc.Wc=double(Region_trans); 
Tc.Wc=zeros(region_num);%Initialize to be computed
Tc.T=zeros(region_num);
% Tc.Path=cell(region_num);

%% Establish LTL formula and Buchi automaton
% Problem 2
N_p=6;%number of atomic propositions that appear in the LTL formula
phi='F(p2 & F(p5)) & FG(p6)' ; %LTL formula

alphabet=alphabet_set(obtainAlphabet(N_p));% alphabet, it is the powerset 2^{AP}, where AP is the set of atomic propositions
B1=create_buchi(phi,alphabet);%GF (p1 & F (p2 & F (p3 & F p4)) & G(!p5))
%%%% Negation "!" and Until "U" do not work correctly in create_buchi.m .

%% Discretize the maps and find center point of all sub-areas
%  Construct the sub-areas
state=cell(1,region_num);
pentagon=linspace(2*pi,0,6);
state{2}=[3.5+cos(pentagon);-3.5+sin(pentagon)];
state{3}=[-1,-0.5,0,-1;1,1.5,1,1];
state{4}=[-4.25,-4.25,-3.75,-3.75,-4.25;3.75,4.25,4.25,3.75,3.75];
state{5}=[4,4;3.7,3.7];
state{6}=[-4.3,-4.3,-4,-4,-4.3;-4.3,-3.7,-3.7,-4.3,-4.3];
[map1,map2]=poly2ccw(Map(1,:),Map(2,:));
s1_x = [map1,NaN,state{2}(1,:),NaN,state{3}(1,:),...
        NaN,state{4}(1,:),NaN,state{5}(1,:),NaN,state{6}(1,:)];%,NaN,ObstacleMap(1,:)];
s1_y = [map2,NaN,state{2}(2,:),NaN,state{3}(2,:),...
        NaN,state{4}(2,:),NaN,state{5}(2,:),NaN,state{6}(2,:)];%,NaN,ObstacleMap(2,:)];
state{1}=[s1_x;s1_y];
centroids=zeros(2,region_num);
centroids(:,1)=[0;0];
for ii=2:region_num
    centroids(:,ii)=sum(state{ii}(:,1:end-1),2)/size(state{ii}(:,1:end-1),2);
end
%% Compute the communication range for large SNR
k_spreading_factor=1.5; % practical spreading
%k=2 for spherical spreading
%k=1 for cylindrical spreading
f=85;% acoustic frequency
N1=50; % Parameter in noise
eta_noise=18; % Parameter in noise
SNR_bar=10; % SNR threshold
P=1e8; % Acoustic power
delta_f=30; % receiver noise bandwidth
if f<1000
    a_f=(0.11*f^2/(1+f^2)+44*f^2/(4100+f)+2.75*1e-4*f^2+0.003);
elseif f>=1000
    a_f=(0.002+0.11*f^2/(1+f^2)+0.011*f^2);
end
syms range_l
eqn= 10*log10(P/delta_f)-k_spreading_factor*10*log10(range_l)-range_l*a_f-N1+eta_noise*log10(f)==10*log10(SNR_bar);
solv=solve(eqn,range_l);
l=vpa(solv);
%l is the range that satisfies the SNR requirement

%% Compute the heuristic weight function
% % % obj=RRTstar(N,robot_mode_ratio,current_mode,vel_mode,x_init,x_goal);
Region_trans=~cellfun('isempty',Tc.trans);
% % N=1000;
% % robot_mode_ratio=0.5;
% current_mode='MeanderingJet';
% vel_mode='Constant';
for i=1:size(Region_trans,1)
%     x_init=centroids(:,i); 
%     %Need to sample from initial points in the connected regions first,
%     %then define the goal points and find the paths
    for j=1:size(Region_trans,2)
        if i==j
            subcost=1e-5;
            subtime=0;
%             subpath=x_init;
        elseif Region_trans(i,j)==0
            subcost=0;
            subtime=0;
%             subpath=[];
        else
%             [subMap_x,subMap_y]=polybool('union',state{i}(1,:),state{i}(2,:),state{j}(1,:),state{j}(2,:));
%             % Merge two connected regions
%             subMap=[subMap_x;subMap_y];
%             subObstacleMap=ObstacleMap;
%             obj=RRTstar(subMap,subObstacleMap,robot_mode_ratio,current_mode,vel_mode);
%             %Should I change obstacle Map accordingly? Regard it as no
%             %obstacle so far
%             G_init=obj.ConstructTree(x_init,N);
%             x_goal=centroids(:,j);
%             [subcost,subtime,subpath,~]=obj.findpath(G_init,x_init,x_goal);...l);
            subtime=sqrt((centroids(1,i)-centroids(1,j))^2+(centroids(2,i)-centroids(2,j))^2)/obj.v_max;
            subcost=obj.cd*obj.v_max^3*subtime;
        end
        Tc.Wc(i,j)=subcost;
        Tc.T(i,j)=subtime;
%         Tc.Path{i,j}=subpath;
    end
end

%% Compute the optimal run
Aprod=FullProd(Tc,B1);
gamma=1;
[hcost,optrunPre,optrunSuf] = OptRun(Aprod,Aprod.Q0,gamma);
% Heuristic cost is the energy cost for straight paths in highest speed
% without currents

%% Calculate the real costs and path, plot the whole map
x_init=centroids(:,optrunPre{1}(1));
start_time=0;
start_cost=0;
PrePath=[x_init;1;start_time;start_cost];
precost=0;
pretime=start_time;
pretotalcost=0;
for k=1:length(optrunPre)-1
    prestate=optrunPre{k}(1);
    sufstate=optrunPre{k+1}(1);
%     if prestate==1 && sufstate==1% Merge regions with holes
%         
%     else
        [subMap_x,subMap_y]=polybool('union',state{prestate}(1,:),state{prestate}(2,:),...
            state{sufstate}(1,:),state{sufstate}(2,:));
%     end
    % Merge two connected regions
    subMap=[subMap_x;subMap_y];
    subObstacleMap=ObstacleMap;
    obj=RRTstar_time_v3(subMap,subObstacleMap,time_ratio,current_mode,time_mode,pretime);
    %Should I change obstacle Map accordingly? Regard it as no
    %obstacle so far
    G_init=obj.ConstructTree(x_init,N);
    x_goal=state{sufstate};
    if ismember(sufstate,[5]) % state with receivers
%         sloc=[centroids(1,sufstate)+1;centroids(2,sufstate)-1];
        [subtotalcost,subcost,subtime,subpath,~]=obj.findpath(G_init,x_init,x_goal(:,1),l);
    else
        [subtotalcost,subcost,subtime,subpath,~]=obj.findpath(G_init,x_init,x_goal);
    end
    precost=subcost+precost;
    pretime=subtime+pretime;
    pretotalcost=pretotalcost+subtotalcost;
    x_init=subpath(1:3,end);
    PrePath=[PrePath,subpath(:,2:end)];
end
sufcost=0;
suftime=pretime;
suftotalcost=0;
SufPath=[];
x_init=PrePath(1:3,end);
if length(optrunSuf)<=1
    SufPath=PrePath(:,end);
else
    for k=1:length(optrunSuf)-1
        prestate=optrunPre{k}(1);
        sufstate=optrunPre{k+1}(1);
        [subMap_x,subMap_y]=polybool('union',state{prestate}(1,:),state{prestate}(2,:),...
        state{sufstate}(1,:),state{sufstate}(2,:));
        % Merge two connected regions
        subMap=[subMap_x;subMap_y];
        subObstacleMap=ObstacleMap;
        obj=RRTstar_time_v3(subMap,subObstacleMap,time_ratio,current_mode,time_mode,suftime);
        %Consider there is no obstacle in the sub region, otherwise regard
        %the obstacle as an separate region.
        G_init=obj.ConstructTree(x_init,N);
        x_goal=state{sufstate};
        if ismember(sufstate,[5]) % state with receivers
%             sloc=[centroids(1,sufstate)+1;centroids(2,sufstate)-1];
            [subtotalcost,subcost,subtime,subpath,~]=obj.findpath(G_init,x_init,x_goal(:,1),l);
        else
            [subtotalcost,subcost,subtime,subpath,~]=obj.findpath(G_init,x_init,x_goal);
        end
        sufcost=subcost+sufcost;
        suftime=subtime+suftime;
        suftotalcost=suftotalcost+subtotalcost;
        x_init=subpath(1:3,end);
        SufPath=[SufPath,subpath(:,2:end)];
    end
end
cost=precost+gamma*sufcost;
time=pretime+gamma*(suftime-pretime);
totalcost=pretotalcost+gamma*suftotalcost;
% pre_path_time=linspace(0,pretime,51);
path_time=[PrePath(4,:),SufPath(4,:)];
length_prepath=size(PrePath,2);
obj=RRTstar_time_v3(Map,ObstacleMap,time_ratio,current_mode,time_mode,start_time);
figure();
hold on
for i_plot=1:length(path_time)
    obj.PlotMap();
    hold on
    % Plot Map
    % plot(ObstacleMap(1,:),ObstacleMap(2,:),'k-','LineWidth',2);
    text(-3,-2.5,'Obstacle','color','black','FontSize',10);
    % % Plot Obstacle
    state_list={'','r1','r2','r3','Sender','Home'};
    for i_s=2:length(state)
        plot(state{i_s}(1,:),state{i_s}(2,:),'g-','LineWidth',2);
        text(centroids(1,i_s),centroids(2,i_s),state_list{i_s},'color','black','FontSize',10);
    end
    % Plot states
    cr = linspace(0,2*pi);
    plot(centroids(1,5)+l*cos(cr),centroids(2,5)+l*sin(cr),'k');
    % Plot communication range
    obj.PlotCurrent(path_time(i_plot));
    % Plot currents
    if i_plot<=length_prepath
        obj.PlotPath(PrePath(:,1:i_plot))
%     plot(PrePath(1,1:i_plot),PrePath(2,1:i_plot),'r-',...
%         'LineWidth',2,...
%         'Marker','o',...
%         'MarkerSize',2,...
%         'MarkerFacecolor','r',...
%         'MarkerEdgeColor','r');
    else
        obj.PlotPath(PrePath);
        plot(SufPath(1,1:(i_plot-length_prepath)),SufPath(2,1:(i_plot-length_prepath)),'k-',...
            'LineWidth',1,...
            'Marker','o',...
            'MarkerSize',1,...
            'MarkerFacecolor','k',...
            'MarkerEdgeColor','k');
    end
    % Plot paths
    m(i_plot)=getframe;          %save the plot frame into m matrix
    hold off;
end
fprintf('Running time is %fs\n',toc);
fprintf('Heuristic cost is %f\n',hcost);
fprintf('Energy cost is %f\n',cost);
fprintf('Traveling time is %f\n',time);
fprintf('Total cost is %f\n',totalcost);
fprintf('\n');
end