function d = CheckTranB(qm,l,qn,Buchi) 
% check the transition between two states qm and qn in the buchi automaton
% following the label function l.
d = -1;

[lidx,loc] = ismember(l,Buchi.alphabet);
if find(lidx)
    if ismember(loc,Buchi.trans{qm,qn})
        d = 0;
    end
end

end