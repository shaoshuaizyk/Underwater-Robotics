%Draw different plots
close all;
clear;
clc;
Map = [-5,-5,5,5,-5;-5,5,5,-5,-5];%Clockwise by default
ObstacleMap=[];
time_ratio=[0,0.25,0.5,0.75,1];%[0.01,0.05,0.1,1,10];
N=4000;%[500,1000,1500,2000];
% time_mode='Constant';
% time_mode='Variable';
m=cell(1,length(time_ratio));
start_time=0;
for i=1:length(time_ratio)
    a=RRTstar_time_v3(Map,ObstacleMap,time_ratio(i),'MeanderingJet','Variable',start_time);
    [path1,tree1,m{i}]=a.main(N,[4;-4;1],[-4;4;1]);
%     a=RRTstar_time(N,0,'MeanderingJet',time_mode,[4;-4],[-4;4]);
%     [p2,g2]=a.main();
%     a=RRTstar_time(N,0.5,'Circle',time_mode,[-4;0],[4;0]);
%     [p3,g3]=a.main();
%     a=RRTstar_time(N,0.5,'MeanderingJet',time_mode,[4;-4],[-4;4]);
%     [p4,g4]=a.main();
%     a=RRTstar_time(N,1,'Circle',time_mode,[-4;0],[4;0]);
%     [p5,g5]=a.main();
%     a=RRTstar_time(N,1,'MeanderingJet',time_mode,[4;-4],[-4;4]);
%     [p6,g6]=a.main();
%     a=RRTstar_time(N,0,'Converge',time_mode,[0;0],[4;4]);
%     [p7,g7]=a.main();
end