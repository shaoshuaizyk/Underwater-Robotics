clear;
clc;

N_p=2;%number of atomic propositions that appear in the LTL formula
phi='(p1) U (p2)' ; %LTL formula
alphabet=alphabet_set(obtainAlphabet(N_p));% alphabet, it is the powerset 2^{AP}, where AP is the set of atomic propositions
B1=create_buchi(phi,alphabet);%GF (p1 & F (p2 & F (p3 & F p4)) & G(!p5))

%%%% Negation "!" and Until "U" do not work correctly in create_buchi.m .