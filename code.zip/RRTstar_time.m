classdef RRTstar_time
    properties
%         Map = [-50,-50,50,50,-50;-50,50,50,-50,-50];%for circle current
%         Map=[0,0,100,100,0;0,100,100,0,0];% Default clockwise
        Map = [-5,-5,5,5,-5;-5,5,5,-5,-5]; %make sure origin is in the map
%         ObstacleMap=[20,20,40,40,60,60,20;20,60,60,40,40,20,20];
        ObstacleMap=[];
        %If the obstacle areas are separated, use NAN to separate.
        Map_free;
%         Map_current=[];
        x_init=[4;-4];
        x_goal=[-4;4];
    end
    properties
        eta=1; %Range for steer and near function
        N=1000; %Iteration times
%         robot_mode='constant_speed';
%         robot_mode='variant_speed';
%         robot_mode='mix';
        robot_mode_ratio=0.5;
%         current_mode='Circle';
        current_mode='MeanderingJet';
%         current_mode='Converge';
%         current_mode='current_map';
%         current_mode='None';
        time_mode = 'Constant';
%         time_mode = 'Variable';
        large_num;
        % For transforming coordinates into index, make code work faster
        cd = 0.1; % vehicle drag coefficient
        v_current=2;%current velocity for circle currents
%         v_vehicle=2;%vehicle velocity
        v_abs=2;    %absolute velocity for quick robots
        v_max=1.5;    %top speed of robots
        gammaRRTstar;
        % should greater than 4^dim*(vol(Map_free)/vol(unitball))
%         rewire_time;
    end
    
    methods
        function obj=RRTstar_time(N,robot_mode_ratio,current_mode,time_mode,x_init,x_goal)
            obj.N=N;
            obj.robot_mode_ratio=robot_mode_ratio;
            obj.current_mode=current_mode;
            obj.time_mode=time_mode;
            obj.x_init=x_init;
            obj.x_goal=x_goal;
% %             The input can be:
% %             RRTstar()
% %             RRTstar(N)
% %             RRTstar(N,eta)
% %             RRTstar(N,eta,x_init,x_goal)
% %             RRTstar(N,eta,Map,ObstacleMap,x_init,x_goal)
%             switch nargin
%                 case 0
%                     %Do nothing
%                 case 1
%                     obj.N=N;
%                 case 2
%                     obj.N=N;
%                     obj.eta=eta;
%                 case 4
%                     obj.N=N;
%                     obj.eta=eta;
%                     obj.x_init=x_init;
%                     obj.x_goal=x_goal;                    
%                 case 6
%                     obj.N=N;
%                     obj.eta=eta;
%                     obj.x_init=x_init;
%                     obj.x_goal=x_goal;
%                     obj.Map=Map;
%                     obj.ObstacleMap=ObstacleMap;
%                 otherwise
%                     error('Error input');
%             end
            if isempty(obj.ObstacleMap) %No obstacle
                free_x = obj.Map(1,:);
                free_y = obj.Map(2,:);
            else %There is obstacle, so the outer boundary should be
                %counter-clockwise
                if ispolycw(obj.Map(1,:),obj.Map(2,:))
                    [map1,map2]=poly2ccw(obj.Map(1,:),obj.Map(2,:));
                    free_x = [map1,NaN,obj.ObstacleMap(1,:)];
                    free_y = [map2,NaN,obj.ObstacleMap(2,:)];
                end
            end
            obj.Map_free=[free_x;free_y];
            obj.large_num = (max(max(obj.Map)) - min(min(obj.Map)));
            volumn_Map = (max(obj.Map(1,:)) - min(obj.Map(1,:)))*...
                (max(obj.Map(2,:)) - min(obj.Map(2,:)));
            obj.gammaRRTstar = 4^2*volumn_Map;
        end %set object
    
        function [path,graph]=main(obj)%Graph might be used
            tic;
            V=obj.x_init;
            E=[];%zeros(4,obj.N);
            i=0;
%             obj.rewire_time=0;
            x_min=min(obj.Map(1,:));
            x_max=max(obj.Map(1,:));
            y_min=min(obj.Map(2,:));
            y_max=max(obj.Map(2,:));
            while i < obj.N
                G={V,E};
%                 rng('shuffle');
                rand_x = x_min+rand()*(x_max-x_min);
                rand_y = y_min+rand()*(y_max-y_min);
                x_rand = [rand_x;rand_y];
                in = inpolygon(rand_x,rand_y,...
                    obj.Map_free(1,:),obj.Map_free(2,:));
                if in
                    i = i + 1;
                    [V,E]=obj.RRTstar_extend(G,x_rand);
                    if obj.N>2000 && mod(length(V),500)==0
                        disp(length(V));
                    end
                end
            end
            %Then find a path to goal
            [~,E]=obj.RRTstar_extend(G,obj.x_goal);
            E_no = size(E,2);
            path = zeros(2,E_no+1);
            current_x = obj.x_goal;
            flag = 0;
            for k = linspace(E_no+1,1,E_no+1)
                path(:,k) = current_x;
                if isequal(current_x,obj.x_init)
                    flag = 1;
                    break;
                else
                    current_x = obj.RRTparent(current_x, E);
                end
            end
            if flag == 0
                error('Cannot find a path');
            end
            path = path(:,k:end);
            [goalcost,time] = obj.Cost(obj.x_goal,E);
            fprintf('Travel time is %f\n',time);
            fprintf('The cost of the path is %f\n',goalcost);
            fprintf('Finding path costs %fs\n',toc);
            tic;
            figure()
            plot(obj.Map_free(1,:),obj.Map_free(2,:),'b-','LineWidth',2);
            axis equal
            xlim([min(obj.Map(1,:)),max(obj.Map(1,:))]);
            ylim([min(obj.Map(2,:)),max(obj.Map(2,:))]);
            hold on;
            graph = E;
            for i = 1:size(graph,2)
                x = [graph(1,i),graph(3,i)];
                y = [graph(2,i),graph(4,i)];
                plot(x,y,'g-');
                hold on
            end
            obj.current_plot();
            hold on;
            plot(path(1,:),path(2,:),'r-',...
                'LineWidth',2,...
                'Marker','o',...
                'MarkerSize',2,...
                'MarkerFacecolor','r',...
                'MarkerEdgeColor','r');
            text(path(1,1),path(2,1),'Start','color','black','FontSize',14);
            text(path(1,end),path(2,end),'End','color','black','FontSize',14);
            hold off;
            fprintf('Plotting costs %fs\n',toc);
        end %main function ends
    end %Open methods ends
        
    methods(Access = private)
        
        function [V, E] = RRTstar_extend(obj,G,x)
            V_new = G{1};
            E_new = G{2};
            x_nearest = obj.Nearest(G,x);
            x_new = obj.Steer(x_nearest,x);
            if obj.passable(x_nearest, x_new)%, obj.Map_free)
                V_new = obj.RRTaddNode(V_new,x_new);
                x_min = x_nearest;
                X_near = obj.Near(G,x_new,size(G{1},2));
                [cost2min,t_min]=obj.Cost(x_min, E_new);
                [cost_min2new,t_min2new]=obj.costP2P(x_min, x_new, t_min);
                min_cost = cost2min + cost_min2new;
        %         if ~isempty(X_near)
                    for i = 1 : size(X_near,2)
                        if obj.passable(X_near(:,i),x_new)%, obj.Map_free)
                            [cost2near,t_near]=obj.Cost(X_near(:,i), E_new);
                            [cost_near2new,t_near2new]=obj.costP2P(X_near(:,i),x_new,t_near);
                            new_cost = cost2near + cost_near2new;
                            if  new_cost <  min_cost
                                x_min = X_near(:,i);
                                min_cost=new_cost;
                                t_min2new=t_near2new;
                            end
                        end
                    end
        %         end
                E_new = obj.RRTaddEdge(E_new,[x_min; x_new]);    
                X_near = obj.RRTremoveNode(X_near,x_min);
                for j = 1 : size(X_near,2)  %Rewire the graph
                    %[t_rewire,cost2rewire] = obj.Cost(x_new, E_new);
                    %1 output cost,2, time and cost
                    cost_rewire = min_cost +...
                        obj.costP2P(x_new,X_near(:,j),t_min2new);
                    if obj.passable(x_new,X_near(:,j))...,obj.Map_free)...
                            && (obj.Cost(X_near(:,j), E_new) > cost_rewire)
                        x_parent = obj.RRTparent(X_near(:,j), E_new);
                        E_new = obj.RRTremoveEdge(E_new,[x_parent; X_near(:,j)]);
                        E_new = obj.RRTaddEdge(E_new, [x_new; X_near(:,j)]);
%                         obj.rewire_time=obj.rewire_time+1;
                    end
                end
            end
            V = V_new;
            E = E_new;
        end %RRTstar_extend ends
        
        function T_or_F = passable(obj, p1, p2)%, Map_free)
        % The path between two points is passable, including obstacle free
        % and current being unable to stop the robot
%             line_x = [p1(1,:),p2(1,:)];
%             line_y = [p1(2,:),p2(2,:)];
            line_x = linspace(p1(1,:), p2(1,:),obj.large_num);
            line_y = linspace(p1(2,:), p2(2,:),obj.large_num);
%             [xin,yin]=inpolygon(line_x,line_y,Map_free(1,:),Map_free(2,:));
            [in,on]=inpolygon(line_x,line_y,obj.Map_free(1,:),obj.Map_free(2,:));
%             cost=obj.costP2P(p1,p2); % Just regard the cost as inf, so we
%             can set up an edge and then rewire it.
            if all(in + on)% && cost<1e10
                T_or_F = true;
            else
                T_or_F = false;
            end
        end %isObstacleFree ends
        
        function [cost,endtime]=costP2P(obj,p1,p2,start_time)
        %x and y are coordinates
        %x and y can be vectors
        %What if p1 = p2
            line_x = linspace(p1(1,:), p2(1,:),obj.large_num+1);
            line_y = linspace(p1(2,:), p2(2,:),obj.large_num+1);
            t=start_time;
            cost=0;
            x_direction=p2(1)-p1(1);
            y_direction=p2(2)-p1(2);
            interval_dis=sqrt(x_direction^2+y_direction^2)/obj.large_num;
            if x_direction==0 && y_direction==0
                direction_unit=[0;0];
            else
                direction_unit=[x_direction;y_direction]/sqrt(x_direction^2+y_direction^2);
            end
            for ii=1:length(line_x)-1
                [v_cx,v_cy]=obj.current_velocity(line_x(ii),line_y(ii),t);
                v_c=[v_cx;v_cy];
                speedc_along_direction=v_c'*direction_unit;
                vc_along_direction=direction_unit*speedc_along_direction;
                vc_verticle=v_c-vc_along_direction;
                vr_verticle=-vc_verticle;
                constant_speed=1;
                variant_speed =speedc_along_direction<=0;
                clip=obj.robot_mode_ratio*constant_speed+...
                        (1-obj.robot_mode_ratio)*variant_speed;
                %1 for keeping top speed, 0 for varying speed
                speedr_verticle=sqrt(vr_verticle(1)^2+vr_verticle(2)^2);
                speedr_along_direction=sqrt(obj.v_max^2-speedr_verticle^2)*clip;
                vr_along_direction=speedr_along_direction*direction_unit;
                vr_abs=vr_along_direction+vc_along_direction;
                speed_abs_along_direction=sqrt(vr_abs(1)^2+vr_abs(2)^2);
                if direction_unit(1)==0 && direction_unit(2)==0%when p1 = p2
                    c=0;%t doesn't change
                    travel_time=0;
                elseif speedr_verticle<=obj.v_max && vr_abs'*direction_unit>0
                    travel_time=interval_dis/speed_abs_along_direction;
                    speedr=sqrt(speedr_verticle.^2+speedr_along_direction.^2);
                    c=obj.cd*sum(travel_time.*speedr.^3);
                else
                    c=1e50;
                    travel_time=1e50;
                end
                cost=c+cost;
                t=t+travel_time;
            end
            endtime=t;
        end %cross_current ends
        
        function [ux,uy]=current_velocity(obj,x,y,time)
            switch obj.time_mode
                case 'Constant'
                    switch obj.current_mode
                        case 'Circle'
                            ux = -obj.v_current*y./sqrt(x.^2+y.^2+eps);
                            uy =  obj.v_current*x./sqrt(x.^2+y.^2+eps);
                        case 'MeanderingJet'
                            A=1.2;          %average meander width
                            c=0.12;         %phase speed with which they they shift downstream
                            k=2*pi/7.5;     %number of meanders in the unit length
                            w=0.4;          %frequency of the modulation
                            epsilon=0.3;    %amplitude of the modulation
                            time=0; %Time invariant
                            B=A+epsilon*cos(w*time);
                            num=y-B*sin(k*(x-c*time));
                            den=sqrt(1+k^2*B^2*cos(k*(x-c*time)).^2);
                            fra=num./den;
                            %   phi=-tanh(fra);
                            ux = sech(fra).^2./den;
                            uy = ((B^2*k^3*sin(k*(x-c*time))...
                                .*cos(k*(x-c*time)).*num) ./ (den.^3) ...
                                - (y - num)./den).*(-sech(fra).^2);
                        case 'current_map'
                            ux=zeros(1,length(x));
                            uy=zeros(1,length(y));
                        case 'None'
                            ux=zeros(1,length(x));
                            uy=zeros(1,length(y));
                        otherwise
                            error('Wrong Current Mode');
                    end
                case 'Variable'
                    switch obj.current_mode
                        case 'Circle'
                            t=mod(time,4);
                            if t>=0 && t<2
                                ratio=1-t;
                            elseif t>=2 && t<4
                                ratio=-3+t;
                            end
                            ux = -obj.v_current*ratio*y./sqrt(x.^2+y.^2+eps);
                            uy =  obj.v_current*ratio*x./sqrt(x.^2+y.^2+eps);
                        case 'MeanderingJet'
                            A=1.2;          %average meander width
                            c=0.12;         %phase speed with which they they shift downstream
                            k=2*pi/7.5;     %number of meanders in the unit length
                            w=0.4;          %frequency of the modulation
                            epsilon=0.3;    %amplitude of the modulation
                            B=A+epsilon*cos(w*time);
                            num=y-B*sin(k*(x-c*time));
                            den=sqrt(1+k^2*B^2*cos(k*(x-c*time)).^2);
                            fra=num./den;
                            %   phi=-tanh(fra);
                            ux = sech(fra).^2./den;
                            uy = ((B^2*k^3*sin(k*(x-c*time))...
                                .*cos(k*(x-c*time)).*num) ./ (den.^3) ...
                                - (y - num)./den).*(-sech(fra).^2);
                        case 'Converge'
                            dis=sqrt(x.^2+y.^2+eps);
                            direction_unit_x=x./dis;
                            direction_unit_y=y./dis;
                            circle=dis>1;
                            ratio=0.1;
                            clip=ones(length(dis))*ratio+circle*(1-ratio);
                            if time<=10
                                ux=-3*direction_unit_x.*clip;
                                uy=-3*direction_unit_y.*clip;
                            else
                                ux=3*direction_unit_x.*clip;
                                uy=3*direction_unit_y.*clip;    
                            end
                        otherwise
                            error('Wrong Current Mode');
                    end
                otherwise
                    error('Wrong Time Mode');
            end
        end %current_velocity ends
        
        function V_new = RRTaddNode(obj,V,x)
            V_new = [V,x];
        end %RRTaddNode ends
        
        function V_new = RRTremoveNode(obj,V,x)
            if isempty(V)
                V_new = V;
            else
                V_idx = V(2,:)*obj.large_num + V(1,:);
                x_idx = x(2,:)*obj.large_num + x(1,:);
                [judge,idx]=ismember(x_idx,V_idx);
                if judge
                    V(:,idx)=[];
                    V_new = V;
                else
                    error('Cannot remove the node, because the node does not belong to the graph');
    %                 V_new = V;
                end
            end
        end %RRTremoveNode ends
        
        function E_new = RRTaddEdge(obj,E,e)
            if isequal(e(1:2),e(3:4))
            % check if the new edge contains the same node
                E_new = E;
            else
                E_new = [E,e];
            end
        end
        
        function E_new = RRTremoveEdge(obj,E,e)
            E_idx = E(4,:)*obj.large_num^3 + E(3,:)*obj.large_num^2 +...
                E(2,:)*obj.large_num + E(1,:);
            e_idx = e(4,:)*obj.large_num^3 + e(3,:)*obj.large_num^2 +...
                e(2,:)*obj.large_num + e(1,:);
            [judge, idx] = ismember(e_idx, E_idx);
            if judge
                E(:,idx)=[];
                E_new = E;
            else
                error('Cannot remove the edge, because the edge does not in the graph');
            end
        end %RRTremoveEdge ends
        
        function x_nearest = Nearest(obj,G,x)
            V = G{1};
            c = obj.Dis(V,x);
            [~,idx]=min(c);
            x_nearest=V(:,idx);
        end %Nearest ends
        
        function v = Near(obj,G,x,n)
            V = G{1};
            if n == 1
                rn = obj.eta;
            else
                rn = min(sqrt(obj.gammaRRTstar*log(n)/(pi*n)),obj.eta);
            end
            v = V(:,logical(obj.Dis(V,x)<=rn));
        end % Near ends
        
        function z = Steer(obj,x,y)
            if isequal(obj.x_goal,y) || obj.Dis(x,y) <= obj.eta
                z = y;
            else
                theta = linspace(0,2*pi,100);
                %Form a circle with r=eta first
                z1 = obj.eta * cos(theta);
                z2 = obj.eta * sin(theta);
                z = [z1;z2];
                z=x-z;
                %The circle center is at x
                D = obj.Dis(z,y);
                [~,idx]=min(D);
                z=z(:,idx);
            end
        end %Steer ends
        
        function x_p = RRTparent(obj, x, E)
            dim = 2;
            parentNode = E(1:dim,:);
            childNode = E(dim+1:end,:);
            childNode_idx = childNode(2,:)*obj.large_num + childNode(1,:);
            x_idx = x(2,:)*obj.large_num + x(1,:);
            [judge, idx] = ismember(x_idx,childNode_idx);
            if judge
                x_p = parentNode(:,idx);
            else
                error('cannnot find a parent node');
            end
        end %RRTparent ends
        
        function [cost,reachtime] = Cost(obj, x, E)
            % The cost from initial point to current point
            % The difference between time-variant and time-invariant here
            % is that the time-variant P2Pcost needs initial time, so it
            % should be find the path first and then calculate the cost and
            % travel time
            reachtime=0;
            cost = 0;
            if isempty(E)
                return
            end
            %Find a path to current node
            E_no = size(E,2);
            path = zeros(2,E_no+1);
            current_x = x;
            flag = 0;
            for k = linspace(E_no+1,1,E_no+1)
                path(:,k) = current_x;
                if isequal(current_x,obj.x_init)
                    flag = 1;
                    break;
                else
                    current_x = obj.RRTparent(current_x, E);
                end
            end
            if flag == 0
                error('Cannot find a path');
            end
            path = path(:,k:end);
            t=0;
            if size(path,2)~=1
                for i = 1 : length(path)-1
                    [c,t]=obj.costP2P(path(:,i),path(:,i+1),t);
                    cost = cost + c;
                    %reachtime=t;
                end
            end
            reachtime=t;
        end %Cost ends
        
        function c = Dis(obj,p1,p2)
        % generate a array consists of all distances from x1 to x2, the length of c
        % is equal to length of x1 or x2, which is longer.
            c = sqrt((p1(1,:) - p2(1,:)).^2+(p1(2,:) - p2(2,:)).^2);
        end
        
        function current_plot(obj)
            X=linspace(min(obj.Map(1,:)), max(obj.Map(1,:)), obj.large_num);
            Y=linspace(min(obj.Map(2,:)), max(obj.Map(2,:)), obj.large_num);
            [x,y]=meshgrid(X,Y);
            [ux,uy]=obj.current_velocity(x,y,0);
            quiver(X,Y,ux,uy);
        end %current_plot ends
        
    end %Private methods end
end