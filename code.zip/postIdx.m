function idx = postIdx(state,trans)

idx_mat = ~cellfun('isempty',trans(state,:));
idx=find(idx_mat);

end