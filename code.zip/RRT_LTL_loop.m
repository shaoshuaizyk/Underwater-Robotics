close all
clc;
clear;
% aaa=RRTstar;
% N_list=[4000];
% rsr_list=[0,0.5,1];
% for j1=1:length(rsr_list)
%     for j2=1:length(N_list)
%         robot_mode_ratio=rsr_list(j1);
%         N=N_list(j2);
%         [~,~]=aaa.main(N,[-4;0],[4;0],robot_mode_ratio,'Circle');
%         [~,~]=aaa.main(N,[-4;0],[4;0],robot_mode_ratio,'MeanderingJet');
%         [~,~]=aaa.main(N,[4;-4],[-4;4],robot_mode_ratio,'MeanderingJet');
%     end
% end
% 
N_list=[4000];%500,1000,2000,4000];
tr_list=[0,0.1,0.2];%[0.01,0.05,0.1,1,10];
m=cell(1,length(N_list)*length(tr_list));
for i1=1:length(tr_list)
    for i2=1:length(N_list)
        time_ratio=tr_list(i1);
        N=N_list(i2);
        m{i2+(i1-1)*length(N_list)}=RRTstar_LTL2(N,time_ratio);
    end
end

