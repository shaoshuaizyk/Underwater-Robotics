function [cost,run]=DijksCycle(Wp,F)
%Find all the successors to the starting state and generate all the 
%shortest path from the successors to the starting state. Compare the cost 
%of all the self loop path and choose the shortest one.
IdxNext=find(Wp(F,:));%Find all the successors, usually the cost to itself is zero
if isempty(IdxNext)
    cost=1e-10;
    run=F;
else
    NoNext=length(IdxNext);
    costMat=zeros(1,NoNext);
    runCell=cell(1,NoNext);
    for i=1:NoNext
        costMat(i)=Wp(F,IdxNext(i));
        if isequal(F,IdxNext(i))
            runCell{i}=F;
        else
            [costNext,runNext,~]=graphshortestpath(Wp,IdxNext(i),F);
            costMat(i)=costMat(i)+costNext;
            if ~isempty(runNext)
                runNext=[F,runNext];%Add the starting state to the path.
                runCell{i}=runNext;
            end
        end
    end
    [cost,runIdx]=min(costMat);
    run=runCell{runIdx};
end
end