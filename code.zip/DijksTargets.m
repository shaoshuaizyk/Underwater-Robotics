function [cost,run]=DijksTargets(Wp,Q0,F)
[cost,run,~] = graghshortestpath(Wp,Q0,F);
end