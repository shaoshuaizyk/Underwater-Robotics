Tc.region=[1,2,3,4,5];
Tc.region0=[1];
Tc.trans={'','sigma1','sigma2','','';
          '','','sigma1','sigma1','';
          '','','sigma1','sigma2','sigma1';
          '','sigma2','sigma1','','';
          '','','sigma1','','sigma1'};
Tc.Lc={'p1','p2','p3','p4','p4'}; %The connection between the system and NBA.
Tc.Wc=[0,1,2,0,0;
       0,0,3,4,0;
       0,0,5,6,7;
       0,8,9,0,0;
       0,0,10,0,11];