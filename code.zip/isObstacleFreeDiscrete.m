function T_or_F = isObstacleFreeDiscrete(p1,p2,X)
% Check obstacle in 2D or 3D maps,p is dim-by-1 vector
    relative_pos = abs(p2 - p1);
    [max_dis, ~] = max(relative_pos);
    sample_point = zeros(length(p1),max_dis+1);
    if max_dis == 0
        sample_point = p1;
    else
        for i = 1:length(p1)
            sample_point(i,:) = linspace(p1(i),p2(i),max_dis+1); %dim-by-n matrix
        end
    end
    check_point=[floor(sample_point),ceil(sample_point)];
    num_ckpt = size(check_point,2);
    check_point_idx = zeros(1,num_ckpt);
    if length(p1)==2
        for j = 1:num_ckpt
            check_point_idx(j) = sub2ind(size(X),check_point(2,j),check_point(1,j));
            % The coordinates and subscripts are different
        end
    elseif length(p1)==3
        for j = 1:num_ckpt
            check_point_idx(j) = sub2ind(size(X),check_point(3,j),check_point(2,j),check_point(1,j));
        end
    end
    T_or_F = isempty(find(~X(check_point_idx),1));
end
% 
% function T_or_F = isObstacleFree(p1,p2,X) 
%     [m,~] = size(X);    %m is the x range, n is the y range
%     x1 = p1(1);
%     y1 = p1(2);
%     x2 = p2(1);
%     y2 = p2(2);
%     if x1 == x2
%         y_inc = linspace(y1,y2,abs(y1-y2)+1);
%         idx = (y_inc-1)*m+x1;
%     elseif y1 == y2
%         x_inc = linspace(x1,x2,abs(x1-x2)+1);
%         idx = (y1-1)*m+x_inc;
%     else
%         x_inc = linspace(x1,x2,abs(x1-x2)+1);
%         y_lin = (y1-y2)*(x_inc-x2)/(x1-x2) + y2;
%         y_floor = floor(y_lin);
%         y_ceil = ceil(y_lin);
%         idx_1 = [(y_floor-1)*m+x_inc,(y_ceil-1)*m+x_inc];
%         y_inc = linspace(y1,y2,abs(y1-y2)+1);
%         x_lin = (x1-x2)*(y_inc-y2)/(y1-y2) + x2;
%         x_floor = floor(x_lin);
%         x_ceil = ceil(x_lin);
%         idx_2 = [(y_inc-1)*m+x_floor,(y_inc-1)*m+x_ceil];
%         idx = [idx_1,idx_2];
%     end
%     T_or_F = isempty(find(~X(idx),1));
% end