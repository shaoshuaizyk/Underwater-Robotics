classdef RRTstar_time_v2
%     New version: modularize the main function; update the findpath
%     function;...
% Add another dimension into the configuration space��
% Regard RSR as the third dimension, randomly choose an rsr and a points in
% the configuration space.
% In this case, the cost is the combination of energy cost and time.
% For the graph, node is a 3 by n matrix: x-coordinate, y-coordinate and rsr
% Edge is 6 by n: 1st, 2nd and 3rd rows are parent node coordinates and their rsr,
% 4th, 5th and 6th are children node coordinates and their rsr.
% But x_init and x_goal can be without the rsr part
% FindPath outputs 5 by n matrices, the 4th line is the time, the 5th is
% the total cost at this point

    properties
%         Map = [-50,-50,50,50,-50;-50,50,50,-50,-50];%for circle current
%         Map=[0,0,100,100,0;0,100,100,0,0];% Default clockwise
        Map = [-5,-5,5,5,-5;-5,5,5,-5,-5]; %make sure origin is in the map
%         ObstacleMap=[20,20,40,40,60,60,20;20,60,60,40,40,20,20];
        ObstacleMap=[];
        %If the obstacle areas are separated, use NAN to separate.
        Map_free;
%         Map_current=[];
        x_init;%=[4;-4];
        x_goal;%=[-4;4];
    end
    properties
        eta=1; %Range for steer and near function
        N;%=1000; %Iteration times
        time_ratio;
        start_time;
%         current_mode='Circle';
        current_mode='MeanderingJet';
%         current_mode='Converge';
%         current_mode='current_map';
%         current_mode='None';
%         time_mode = 'Constant';
        time_mode = 'Variable';
        large_num;
        % For transforming coordinates into index, make code work faster
        cd = 0.1; % vehicle drag coefficient
        v_current=2;%current velocity for circle currents
%         v_vehicle=2;%vehicle velocity
        v_abs=2;    %absolute velocity for quick robots
        v_max=1.5;    %top speed of robots
        gammaRRTstar;
        % should greater than 4^dim*(vol(Map_free)/vol(unitball))
%         rewire_time;
    end
    
    methods
        function obj=RRTstar_time_v2(Map,ObstacleMap,time_ratio,current_mode,time_mode,start_time)%,x_init,x_goal)
            if nargin~=0
%                 obj.N=N;
                obj.Map=Map;
                obj.ObstacleMap=ObstacleMap;
                obj.time_ratio=time_ratio;
                obj.current_mode=current_mode;
                obj.time_mode=time_mode;
                obj.start_time=start_time;
%                 obj.eta=eta;
            end
% %             obj.x_init=x_init;
% %             obj.x_goal=x_goal;
% %             The input can be:
% %             RRTstar()
% %             RRTstar(N)
% %             RRTstar(N,eta)
% %             RRTstar(N,eta,x_init,x_goal)
% %             RRTstar(N,eta,Map,ObstacleMap,x_init,x_goal)
%             switch nargin
%                 case 0
%                     %Do nothing
%                 case 1
%                     obj.N=N;
%                 case 2
%                     obj.N=N;
%                     obj.eta=eta;
%                 case 4
%                     obj.N=N;
%                     obj.eta=eta;
%                     obj.x_init=x_init;
%                     obj.x_goal=x_goal;                    
%                 case 6
%                     obj.N=N;
%                     obj.eta=eta;
%                     obj.x_init=x_init;
%                     obj.x_goal=x_goal;
%                     obj.Map=Map;
%                     obj.ObstacleMap=ObstacleMap;
%                 otherwise
%                     error('Error input');
%             end
            if isempty(obj.ObstacleMap) %No obstacle
                free_x = obj.Map(1,:);
                free_y = obj.Map(2,:);
            else %There is obstacle, so the outer boundary should be
                %counter-clockwise
                if all(ispolycw(obj.Map(1,:),obj.Map(2,:)))% No hole
                    [map1,map2]=poly2ccw(obj.Map(1,:),obj.Map(2,:));
                    free_x = [map1,NaN,obj.ObstacleMap(1,:)];
                    free_y = [map2,NaN,obj.ObstacleMap(2,:)];
                else
                    %With holes, the outer and inner boundaries are in opposite directions
                    [obmap1,obmap2]=poly2ccw(obj.ObstacleMap(1,:),obj.ObstacleMap(2,:));
                    free_x = [obj.Map(1,:),NaN,obmap1];
                    free_y = [obj.Map(2,:),NaN,obmap2];
                end
            end
            obj.Map_free=[free_x;free_y];
            obj.large_num = (max(max(obj.Map)) - min(min(obj.Map)));
            volumn_Map = ((max(obj.Map(1,:)) - min(obj.Map(1,:)))*...
                (max(obj.Map(2,:)) - min(obj.Map(2,:))))*1;
            obj.gammaRRTstar = 4^3*volumn_Map;
        end %set object
    
        function [path,graph,m]=main(obj,N,x_init,x_goal)
            %Graph might be used
            tic;
            obj.N=N;
            if size(x_init,1)==2
                x_init=[x_init;1];
            end
            if size(x_goal,1)==2
                x_goal=[x_goal;1];
            end
            obj.x_init=x_init;
            obj.x_goal=x_goal;
            G=obj.ConstructTree(x_init,N);
            [totalcost,goalcost,travel_time,path,graph]=obj.findpath(G,x_init,x_goal);
            fprintf('Finding path costs %fs\n',toc);
%             graph=Ggoal{2}; 
            tic;
            time=path(4,:);
            figure();
            hold on;
            for i=1:length(time)
                obj.PlotMap();
                hold on
                obj.PlotCurrent(time(i));
                obj.PlotGraph(graph);
                obj.PlotPath(path(:,1:i));
                m(i)=getframe;          %save the plot frame into m matrix
                hold off
            end
            fprintf('Plotting costs %fs\n',toc);
            fprintf('The energy cost of the path is %f\n',goalcost);
            fprintf('The travel time is %f\n',travel_time);
            fprintf('The total cost is %f\n',totalcost);
            fprintf('\n');
        end %main ends
            
        function G=ConstructTree(obj,x_init,N)
            obj.N=N;
            if size(x_init,1)==2
                x_init=[x_init;1];
            end
            obj.x_init=x_init;
            V=x_init;
            E=[];%zeros(4,obj.N);
            i=0;
%             obj.rewire_time=0;
            x_min=min(obj.Map(1,:));
            x_max=max(obj.Map(1,:));
            y_min=min(obj.Map(2,:));
            y_max=max(obj.Map(2,:));
            while i < obj.N
                G={V,E};
%                 rng('shuffle');
                rand_x = x_min+rand()*(x_max-x_min);
                rand_y = y_min+rand()*(y_max-y_min);
                rand_rsr=rand();
                x_rand = [rand_x;rand_y;rand_rsr];
                in = inpolygon(rand_x,rand_y,...
                    obj.Map_free(1,:),obj.Map_free(2,:));
                if in
                    i = i + 1;
                    [V,E]=obj.RRTstar_extend(G,x_rand);
                    if obj.N>2000 && mod(length(V),2000)==0
                        disp(length(V));
                    end
                end
            end
        end % ConstructTree ends
        
        function [totalcost,energy_cost,travel_time,path,G]=findpath(obj,G,x_init,x_goal,r,sloc)
%             Then find a path to goal
%             The path is 5 by n matrices, the 4th row is the time, 5th row
%             is the total cost at this node.
            if size(x_init,1)==2
                x_init=[x_init;1];
            end
            if size(x_goal,1)==2 && size(x_goal,2)==1
                x_goal=[x_goal;1];
            end
            obj.x_init=x_init;
            V=G{1};
            E=G{2};
            if size(x_goal,2)==1 % If the goal is a point, add this point to the tree
                obj.x_goal=x_goal;
            elseif size(x_goal,2)>1 && isempty(find(isnan(x_goal(1,:)), 1))
                % No hole area. If there are holes inside, do not choose a inner
                % point to extend
                centroid=sum(x_goal,2)/size(x_goal,2);
                obj.x_goal=[centroid;1];
            end
            if nargin==6 % Add sender into the graph
                [V,E]=obj.RRTstar_extend(G,[sloc;1]);
                G={V,E};
            end
            if ~isempty(obj.x_goal)
                if size(obj.x_goal,1)==2
                    [V,E]=obj.RRTstar_extend(G,[obj.x_goal;1]);
                elseif size(obj.x_goal,1)==3
                    [V,E]=obj.RRTstar_extend(G,obj.x_goal);
                end
                G={V,E};%Add a point in the goal area into the graph
            end
            if nargin==4 && size(x_goal,2)==1
                % A point as a goal
                current_x = x_goal;
            else
                if nargin==5% && size(x_goal,2)==1
                    % a sender location and a range
                    goal_node_idx=obj.Dis(x_goal,V)<=r;
                    % All nodes are less or equal to r away from the sender
                elseif nargin==4 && size(x_goal,2)>1
                    goal_node_idx=inpolygon(V(1,:),V(2,:),x_goal(1,:),x_goal(2,:));
                    % All nodes are in(not on) the goal region
                elseif nargin==6
                    % An area and a sender location and a range
                    goal1_idx=inpolygon(V(1,:),V(2,:),x_goal(1,:),x_goal(2,:));
                    goal2_idx=obj.Dis(sloc,V)<=r;
                    goal_node_idx=goal1_idx & goal2_idx;
                    if isempty(find(goal_node_idx,1))
                        error('Increase sample numbers');
                    end
                end
                goal_node=V(:,goal_node_idx);
                goal_cost=zeros(1,size(goal_node,2));
                for i_goal=1:size(goal_node,2)
                    goal_cost(i_goal)=obj.Cost(goal_node(:,i_goal),E);
                end
                [~,current_x_idx]=min(goal_cost);
                current_x=goal_node(:,current_x_idx);
            end
            E_no = size(E,2);
            path = zeros(5,E_no+1);
            obj.x_goal=current_x;
            
            flag = 0;
            for k = linspace(E_no+1,1,E_no+1)
                path(1:3,k) = current_x;
                if isequal(current_x(1:2,:),obj.x_init(1:2,:))
                    flag = 1;
                    break;
                else
                    current_x = obj.RRTparent(current_x, E);
                end
            end
            if flag == 0
                error('Cannot find a path');
            end
            path = path(:,k:end);
            arrive_time=obj.start_time;
            totalcost=0;
            energy_cost=0;
            path(4,1)=arrive_time;
            path(5,1)=totalcost;
            for i_path=1:size(path,2)-1
                [tc,ec,arrive_time]=obj.costP2P(path(1:3,i_path),path(1:3,i_path+1),arrive_time);
                totalcost=totalcost+tc;
                energy_cost=energy_cost+ec;
                path(4,i_path+1)=arrive_time;
                path(5,i_path+1)=totalcost;
            end
            travel_time=arrive_time-obj.start_time;
%             [totalcost,energy_cost,travel_time] = obj.Cost(obj.x_goal,E);
        end %findpath ends
            
        function PlotMap(obj)
            plot(obj.Map_free(1,:),obj.Map_free(2,:),'b-','LineWidth',2);
            axis equal
            xlim([min(obj.Map(1,:)),max(obj.Map(1,:))]);
            ylim([min(obj.Map(2,:)),max(obj.Map(2,:))]);
        end %PlotMap ends
        
        function PlotCurrent(obj,time)
            X=linspace(min(obj.Map(1,:)), max(obj.Map(1,:)), obj.large_num);
            Y=linspace(min(obj.Map(2,:)), max(obj.Map(2,:)), obj.large_num);
            [x,y]=meshgrid(X,Y);
            [ux,uy]=obj.current_velocity(x,y,time);
            current=quiver(X,Y,ux,uy);
            set(current,'Color','blue');
        end %current_plot ends
        
        function PlotGraph(obj,G)
            E=G{2};
            graph = E;
            for i = 1:size(graph,2)
                x = [graph(1,i),graph(4,i)];
                y = [graph(2,i),graph(5,i)];
                plot(x,y,'g-');
                hold on
            end
        end %PlotCurrent ends
        
        function PlotPath(obj,path)
            plot(path(1,:),path(2,:),'r-',...
                'LineWidth',2,...
                'Marker','o',...
                'MarkerSize',2,...
                'MarkerFacecolor','r',...
                'MarkerEdgeColor','r');
            text(path(1,1),path(2,1),'Start','color','black','FontSize',14);
            text(path(1,end),path(2,end),'End','color','black','FontSize',14);
        end %PlotPath ends
        
    end %Open methods ends
        
    methods(Access = private)
        
        function [V, E] = RRTstar_extend(obj,G,x)
            V_new = G{1};
            E_new = G{2};
            x_nearest = obj.Nearest(G,x);
            x_new = obj.Steer(x_nearest,x);
            if obj.passable(x_nearest, x_new)%, obj.Map_free)
                V_new = obj.RRTaddNode(V_new,x_new);
                x_min = x_nearest;
                X_near = obj.Near(G,x_new,size(G{1},2));
                %Find the rsr belongs to the edge
%                 if isempty(E_new)% First extension
%                     pre_rsr=rand();
%                 else
%                     E_idx=E_new(2,:)*obj.large_num+E_new(1,:);
%                     X_idx=x_min(2,:)*obj.large_num+x_min(1,:);
%                     [~,idx]=ismember(X_idx,E_idx);
%                     pre_rsr=E_new(5,idx);
%                 end
                %Use that rsr to calculate the cost of new edge
                [cost2min,~,t_min]=obj.Cost(x_min, E_new);
                [cost_min2new,~,t_min2new]=obj.costP2P(x_min, x_new, t_min);
                min_cost = cost2min + cost_min2new;
        %         if ~isempty(X_near)
                    for i = 1 : size(X_near,2)
                        if obj.passable(X_near(:,i),x_new)%, obj.Map_free)
                            %Find the rsr belongs to the edge
%                             if ~isempty(E_new) % First extension already has rsr
%                                 E_idx=E_new(2,:)*obj.large_num+E_new(1,:);
%                                 X_idx=X_near(2,i)*obj.large_num+X_near(1,i);
%                                 [~,idx]=ismember(X_idx,E_idx);
%                                 pre_rsr=E_new(5,idx);
%                             end
                            %Use that rsr to calculate the cost of new edge
                            [cost2near,~,t_near]=obj.Cost(X_near(:,i), E_new);
                            [cost_near2new,~,t_near2new]=obj.costP2P(X_near(:,i),x_new,t_near);
                            new_cost = cost2near + cost_near2new;
                            if  new_cost <  min_cost
                                x_min = X_near(:,i);
                                min_cost=new_cost;
                                t_min2new=t_near2new;
                            end
                        end
                    end
        %         end
                E_new = obj.RRTaddEdge(E_new,[x_min; x_new]);    
                X_near = obj.RRTremoveNode(X_near,x_min);
                for j = 1 : size(X_near,2)  %Rewire the graph
                    %[t_rewire,cost2rewire] = obj.Cost(x_new, E_new);
                    %1 output cost,2, time and cost
                    cost_rewire = min_cost + obj.costP2P(x_new,X_near(:,j),t_min2new);
                    if obj.passable(x_new,X_near(:,j)) && (obj.Cost(X_near(:,j), E_new) > cost_rewire)
                        x_parent = obj.RRTparent(X_near(:,j), E_new);
                        E_new = obj.RRTremoveEdge(E_new,[x_parent; X_near(:,j)]);
                        E_new = obj.RRTaddEdge(E_new, [x_new; X_near(:,j)]);
%                         obj.rewire_time=obj.rewire_time+1;
                    end
                end
            end
            V = V_new;
            E = E_new;
        end %RRTstar_extend ends
        
        function T_or_F = passable(obj, p1, p2)%, Map_free)
        % The path between two points is passable, including obstacle free
        % and current being unable to stop the robot
%             line_x = [p1(1,:),p2(1,:)];
%             line_y = [p1(2,:),p2(2,:)];
            line_x = linspace(p1(1,:), p2(1,:),obj.large_num);
            line_y = linspace(p1(2,:), p2(2,:),obj.large_num);
%             [xin,yin]=inpolygon(line_x,line_y,Map_free(1,:),Map_free(2,:));
            [in,on]=inpolygon(line_x,line_y,obj.Map_free(1,:),obj.Map_free(2,:));
%             cost=obj.costP2P(p1,p2); % Just regard the cost as inf, so we
%             can set up an edge and then rewire it.
            if all(in + on)% && cost<1e10
                T_or_F = true;
            else
                T_or_F = false;
            end
        end %isObstacleFree ends
        
        function [totalcost,energycost,endtime]=costP2P(obj,p1,p2,start_time)
        %x and y are coordinates
        %x and y can be vectors
        %What if p1 = p2? impossible in this algorithm
            line_x = linspace(p1(1,:), p2(1,:),obj.large_num+1);
            line_y = linspace(p1(2,:), p2(2,:),obj.large_num+1);
            robot_speed_ratio=p1(3);
            t=start_time;
            energycost=0;
            x_direction=p2(1)-p1(1);
            y_direction=p2(2)-p1(2);
            interval_dis=sqrt(x_direction^2+y_direction^2)/obj.large_num;
            if x_direction==0 &&  y_direction==0
                direction_unit=[0;0];
            else
                direction_unit=[x_direction;y_direction]/sqrt(x_direction^2+y_direction^2);
            end
            for ii=1:length(line_x)-1
                [v_cx,v_cy]=obj.current_velocity(line_x(ii),line_y(ii),t);
                v_c=[v_cx;v_cy];
                speedc_along_direction=v_c'*direction_unit;
                vc_along_direction=direction_unit*speedc_along_direction;
                vc_verticle=v_c-vc_along_direction;
                vr_verticle=-vc_verticle;
                constant_speed=1;
                variant_speed =speedc_along_direction<0;
                clip=robot_speed_ratio*constant_speed+...
                        (1-robot_speed_ratio)*variant_speed;
                %1 for keeping top speed, 0 for varying speed
                speedr_verticle=sqrt(vr_verticle(1)^2+vr_verticle(2)^2);
                speedr_along_direction=sqrt(obj.v_max^2-speedr_verticle^2)*clip;
                vr_along_direction=speedr_along_direction*direction_unit;
                vr_abs=vr_along_direction+vc_along_direction;
                speed_abs_along_direction=sqrt(vr_abs(1)^2+vr_abs(2)^2);
                if direction_unit(1)==0 && direction_unit(2)==0%when p1 = p2
                    c=0;%t doesn't change
                    travel_time=0;
                elseif speedr_verticle<=obj.v_max && vr_abs'*direction_unit>0
                    travel_time=interval_dis/speed_abs_along_direction;
                    speedr=sqrt(speedr_verticle.^2+speedr_along_direction.^2);
                    c=obj.cd*sum(travel_time.*speedr.^3);
                else
                    c=1e50;
                    travel_time=1e50;
                end
                energycost=c+energycost;
                t=t+travel_time;
            end
            endtime=t;
            totalcost=energycost+obj.time_ratio*(endtime-start_time);
        end %cross_current ends
        
        function [ux,uy]=current_velocity(obj,x,y,time)
            switch obj.time_mode
                case 'Constant'
                    switch obj.current_mode
                        case 'Circle'
                            ux = -obj.v_current*y./sqrt(x.^2+y.^2+eps);
                            uy =  obj.v_current*x./sqrt(x.^2+y.^2+eps);
                        case 'MeanderingJet'
                            A=1.2;          %average meander width
                            c=0.12;         %phase speed with which they they shift downstream
                            k=2*pi/7.5;     %number of meanders in the unit length
                            w=0.4;          %frequency of the modulation
                            epsilon=0.3;    %amplitude of the modulation
                            time=0; %Time invariant
                            B=A+epsilon*cos(w*time);
                            num=y-B*sin(k*(x-c*time));
                            den=sqrt(1+k^2*B^2*cos(k*(x-c*time)).^2);
                            fra=num./den;
                            %   phi=-tanh(fra);
                            ux = sech(fra).^2./den;
                            uy = ((B^2*k^3*sin(k*(x-c*time))...
                                .*cos(k*(x-c*time)).*num) ./ (den.^3) ...
                                - (y - num)./den).*(-sech(fra).^2);
                        case 'current_map'
                            ux=zeros(1,length(x));
                            uy=zeros(1,length(y));
                        case 'None'
                            ux=zeros(1,length(x));
                            uy=zeros(1,length(y));
                        otherwise
                            error('Wrong Current Mode');
                    end
                case 'Variable'
                    switch obj.current_mode
                        case 'Circle'
                            t=mod(time,4);
                            if t>=0 && t<2
                                ratio=1-t;
                            elseif t>=2 && t<4
                                ratio=-3+t;
                            end
                            ux = -obj.v_current*ratio*y./sqrt(x.^2+y.^2+eps);
                            uy =  obj.v_current*ratio*x./sqrt(x.^2+y.^2+eps);
                        case 'MeanderingJet'
                            A=1.2;          %average meander width
                            c=0.12;         %phase speed with which they they shift downstream
                            k=2*pi/7.5;     %number of meanders in the unit length
                            w=0.4;          %frequency of the modulation
                            epsilon=0.3;    %amplitude of the modulation
                            B=A+epsilon*cos(w*time);
                            num=y-B*sin(k*(x-c*time));
                            den=sqrt(1+k^2*B^2*cos(k*(x-c*time)).^2);
                            fra=num./den;
                            %   phi=-tanh(fra);
                            ux = sech(fra).^2./den;
                            uy = ((B^2*k^3*sin(k*(x-c*time))...
                                .*cos(k*(x-c*time)).*num) ./ (den.^3) ...
                                - (y - num)./den).*(-sech(fra).^2);
                        case 'Converge'
                            dis=sqrt(x.^2+y.^2+eps);
                            direction_unit_x=x./dis;
                            direction_unit_y=y./dis;
                            circle=dis>1;
                            ratio=0;
                            clip=ones(1,length(dis))*ratio+circle*(1-ratio);
                            if time<=10
                                ux=-3*direction_unit_x.*clip;
                                uy=-3*direction_unit_y.*clip;
                            else
                                ux=3*direction_unit_x.*clip;
                                uy=3*direction_unit_y.*clip;    
                            end
                        otherwise
                            error('Wrong Current Mode');
                    end
                otherwise
                    error('Wrong Time Mode');
            end
        end %current_velocity ends
        
        function V_new = RRTaddNode(obj,V,x)
            V_new = [V,x];
        end %RRTaddNode ends
        
        function V_new = RRTremoveNode(obj,V,x)
            if isempty(V)
                V_new = V;
            else
                V_idx = V(2,:)*obj.large_num + V(1,:);
                x_idx = x(2,:)*obj.large_num + x(1,:);
                [judge,idx]=ismember(x_idx,V_idx);
                if judge
                    V(:,idx)=[];
                    V_new = V;
                else
                    error('Cannot remove the node, because the node does not belong to the graph');
    %                 V_new = V;
                end
            end
        end %RRTremoveNode ends
        
        function E_new = RRTaddEdge(obj,E,e)
            if isequal(e(1:2),e(4:5))
            % check if the new edge contains the same node
                E_new = E;
            else
                E_new = [E,e];
            end
        end
        
        function E_new = RRTremoveEdge(obj,E,e)
            E_idx = E(5,:)*obj.large_num^3 + E(4,:)*obj.large_num^2 +...
                E(2,:)*obj.large_num + E(1,:);
            e_idx = e(5,:)*obj.large_num^3 + e(4,:)*obj.large_num^2 +...
                e(2,:)*obj.large_num + e(1,:);
            [judge, idx] = ismember(e_idx, E_idx);
            if judge
                E(:,idx)=[];
                E_new = E;
            else
                error('Cannot remove the edge, because the edge does not in the graph');
            end
        end %RRTremoveEdge ends
        
        function x_nearest = Nearest(obj,G,x)
            V = G{1};
            c = obj.Dis(V,x);
            [~,idx]=min(c);
            x_nearest=V(:,idx);
        end %Nearest ends
        
        function v = Near(obj,G,x,n)
            V = G{1};
            if n == 1
                rn = obj.eta;
            else
                rn = min(nthroot(obj.gammaRRTstar*log(n)/((4/3*pi*1^3)*n),3),obj.eta);
            end
            v = V(:,logical(obj.Dis(V,x)<=rn));
        end % Near ends
        
        function z = Steer(obj,x,y)
            if obj.Dis(x,y) <= obj.eta || (size(obj.x_goal,2)==1 && isequal(obj.x_goal(1:2,:),y(1:2,:)))
                z = y;
            else
                theta = linspace(0,2*pi,100);
                %Form a circle with r=eta first
                z1 = obj.eta * cos(theta);
                z2 = obj.eta * sin(theta);
                z = [z1;z2];
                z=x(1:2,:)-z;
                %The circle center is at x
                D = obj.Dis(z,y);
                [~,idx]=min(D);
                z=z(:,idx);
                z=[z;y(3)];
            end
        end %Steer ends
        
        function x_p = RRTparent(obj, x, E)
            parentNode = E(1:3,:);
            childNode = E(4:5,:);
            childNode_idx = childNode(2,:)*obj.large_num + childNode(1,:);
            x_idx = x(2,:)*obj.large_num + x(1,:);
            [judge, idx] = ismember(x_idx,childNode_idx);
            if judge
                x_p = parentNode(:,idx);
            else
                error('cannnot find a parent node');
            end
        end %RRTparent ends
        
        function [totalcost,energycost,reachtime] = Cost(obj, x, E)
            % The cost from initial point to current point
            % The difference between time-variant and time-invariant here
            % is that the time-variant P2Pcost needs initial time, so it
            % should be find the path first and then calculate the cost and
            % travel time
            reachtime=obj.start_time;
            energycost = 0;
            totalcost=0;
            if isempty(E)
                return
            end
            %Find a path to current node
            E_no = size(E,2);
            path = zeros(3,E_no+1);
            current_x = x;
            flag = 0;
            for k = linspace(E_no+1,1,E_no+1)
                path(:,k) = current_x;
                if isequal(current_x(1:2,:),obj.x_init(1:2,:))
                    flag = 1;
                    break;
                else
                    current_x = obj.RRTparent(current_x, E);
                end
            end
            if flag == 0
                error('Cannot find a path');
            end
            path = path(:,k:end);
            t=reachtime;
            if size(path,2)~=1
                for i = 1 : size(path,2)-1
                    [tc,c,t]=obj.costP2P(path(:,i),path(:,i+1),t);
                    % the 3rd line of the path is the rsr
                    energycost = energycost + c;
                    totalcost  = totalcost + tc;
                    %reachtime=t;
                end
            end
            reachtime=t;
        end %Cost ends
        
        function c = Dis(obj,p1,p2)
        % generate a array consists of all distances from x1 to x2, the length of c
        % is equal to length of x1 or x2, which is longer.
            c = sqrt((p1(1,:) - p2(1,:)).^2+(p1(2,:) - p2(2,:)).^2);
        end
        
    end %Private methods end
end